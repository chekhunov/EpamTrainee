package ua.nure.kolesnikov.practice7;

/**
 * Demo class to run project WO command line.
 * 
 * @author D.Kolesnikov
 * 
 */
public class Demo {
	
	public static void main(String[] args) throws Exception {
		Main.main(new String[] { "input.xml" });
	}
	
}