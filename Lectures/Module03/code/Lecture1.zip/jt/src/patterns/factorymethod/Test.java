package patterns.factorymethod;

public class Test {
	public static void main(String[] args) {
		Factory factory = new Factory();
		Parser parser = factory.getParser(Factory.XML_FACTORY);
		System.out.println(parser.parse("Message"));
		
		parser = factory.getParser(Factory.JSON_FACTORY);
		System.out.println(parser.parse("Message"));
	}
}
