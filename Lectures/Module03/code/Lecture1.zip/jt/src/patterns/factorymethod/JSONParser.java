package patterns.factorymethod;

// Implementation of known interface
public class JSONParser implements Parser {

	@Override
	public String parse(String msg) {
		return getClass().getSimpleName() + ": " + msg;
	}

}
