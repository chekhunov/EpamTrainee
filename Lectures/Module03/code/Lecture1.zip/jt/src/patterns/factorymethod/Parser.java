package patterns.factorymethod;

//Known interface
public interface Parser {
	String parse(String msg);
}
