package patterns.factorymethod;

// Implementation of known interface
public class XMLParser implements Parser {

	@Override
	public String parse(String msg) {
		return getClass().getSimpleName() + ": " + msg;
	}

}
