package patterns.factorymethod;

// Contains factory method
public class Factory {
	public static final String XML_FACTORY = "XML";
	public static final String JSON_FACTORY = "JSON";
	
	
	// Factory method
	// Returns instance of known interface or abstract class
	public Parser getParser(String whichParser) {
		if (whichParser.equals(XML_FACTORY)) {
			return new XMLParser();
		} else if (whichParser.equals(JSON_FACTORY)) {
			return new JSONParser();
		} 
		throw new UnsupportedClassVersionError();
	}
	
}
