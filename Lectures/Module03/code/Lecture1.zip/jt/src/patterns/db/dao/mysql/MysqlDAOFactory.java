package patterns.db.dao.mysql;

import patterns.db.dao.DAOFactory;
import patterns.db.dao.UserDAO;

/**
 * Реализация DAOFactory для DBMS MySQL.
 * 
 * @author Dmitry Kolesnikov
 * 
 */
public class MysqlDAOFactory extends DAOFactory {

	@Override
	public UserDAO getUserDAO() {
		return new MysqlUserDAO();
	}

	// методы получения DAO для других сущностей
	// ...

}
