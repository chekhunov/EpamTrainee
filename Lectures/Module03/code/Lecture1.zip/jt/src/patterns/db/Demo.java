package patterns.db;

import patterns.db.dao.DAOFactory;
import patterns.db.dao.UserDAO;

/**
 *  ласс, который демонстрирует работу с DAOFactor.
 * 
 * @author Dmitry Kolesnikov
 * 
 */
public class Demo {
	public static void main(String[] args) throws Exception {

		// Derby
		DAOFactory
				.setDaoFactoryFCN("com.epam.jt.example.lect05.db.dao.derby.DerbyDAOFactory");
		DAOFactory daoFactory = DAOFactory.getInstance();
		UserDAO userDAO = daoFactory.getUserDAO();
		userDAO.create(null);

		// MySQL
		DAOFactory
				.setDaoFactoryFCN("com.epam.jt.example.lect05.db.dao.mysql.MysqlDAOFactory");
		daoFactory = DAOFactory.getInstance();
		userDAO = daoFactory.getUserDAO();
		userDAO.create(null);
	}

}
