package patterns.observer2;

// Наблюдатель. Должен быть подписан на наблюдение, вызовом метода addObserver(Observer)
public class Channel implements Observer {

	private String name;

	public Channel() {
	}

	public Channel(String name) {
		this.name = name;
	}

	// Наблюдаемый объект вызывает этот метод во время нотификации
	@Override
	public void update(Object arg) {
		System.out.println("\n" + name + "\nData ---===" + arg + "===---");
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
