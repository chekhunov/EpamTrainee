package patterns.observer2;

import java.util.LinkedList;
import java.util.List;

/**
 * Представляет данные, об изменении которых нужно оповестить наблюдателей
 * 
 * Наблюдатели подписываются на изменения, вызывая метод register(Observer)
 * на том объекте этого класса, который хотят отслеживать
 * 
 * @author engsyst
 *
 */
public class ObservableMessage {
	
	// Наблюдаемые данные
	private List<String> messages = new LinkedList<>(); 

	private List<Observer> observers = new LinkedList<>();

	// Изменяет наблюдаемые данные
	public void add(String message) {
		messages.add(message);

		// Известить наблюдателей
		notifyObservers(message);
	}

	private void notifyObservers(Object message) {
		for (Observer ob : observers) {
			ob.update(message);
		}
	}

	public void register(Observer ob) {
		observers.add(ob);
	}

	public void unregister(Observer ob) {
		observers.remove(ob);
	}
	
	public List<String> getMessages() {
		return messages;
	}

}
