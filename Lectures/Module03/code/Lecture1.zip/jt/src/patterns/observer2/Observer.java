package patterns.observer2;

public interface Observer {
	void update(Object o);
}
