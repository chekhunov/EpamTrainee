package patterns.singleton;

public class Test {
	private static final int COUNT = 5;

	public static void main(String[] args) {
		for (int i = 0; i < COUNT; i++) {
			Singleton s = Singleton.getInstance();
			s.name();
		}
		
	}
}
