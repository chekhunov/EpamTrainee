package patterns.singleton;

/**
 * Singleton pattern<br/>
 * 
 * @author engsyst
 *
 */
public class Singleton {

	private static Singleton instance;

	// hide constructor
	private Singleton() {
	}

	// Always returns a cached instance of this class after it has been created
	public static synchronized Singleton getInstance() {
		if (instance == null) {
			instance = new Singleton();
		}
		return instance;
	}

	public void name() {
		System.out.println(instance);
	}
}
