
package patterns.immutable;

import java.util.Objects;

/**
 * Immutable object pattern<br/>
 * 
 * Fields are constants whose values ​​are accepted in the constructor.
 * No methods change the internal state of an object.
 * 
 * @author engsyst
 *
 */
public class Money {

	final private double value;
	final private String currency;

	public Money(double value, String currency) {
		this.value = value;
		this.currency = currency;
	}

	public double getValue() {
		return value;
	}
	
	public String getCurrency() {
		return currency;
	}
	
	public Money add(Money m) {
		if (Objects.equals(m.currency, currency))
			return new Money(value + m.value, currency);
		throw new IllegalArgumentException("Currency not equal");
	}

	public Money substract(Money m) {
		if (Objects.equals(m.currency, currency))
			return new Money(value - m.value, currency);
		throw new IllegalArgumentException("Currency not equal");
	}
	
	public Money toCurrency(String currency) {
		return new Money(value * getFactor(this.currency, currency), currency);
	}

	private double getFactor(String currency2, String currency3) {
		return 2.8;
	}

	@Override
	public String toString() {
		StringBuilder builder = new StringBuilder();
		builder.append(super.toString());
		builder.append(": Money [value=");
		builder.append(value);
		builder.append(", ");
		if (currency != null) {
			builder.append("currency=");
			builder.append(currency);
		}
		builder.append("]");
		return builder.toString();
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((currency == null) ? 0 : currency.hashCode());
		long temp;
		temp = Double.doubleToLongBits(value);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Money other = (Money) obj;
		if (currency == null) {
			if (other.currency != null)
				return false;
		} else if (!currency.equals(other.currency))
			return false;
		if (Double.doubleToLongBits(value) != Double.doubleToLongBits(other.value))
			return false;
		return true;
	}
	
	
}
