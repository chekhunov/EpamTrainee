package patterns.immutable;

public class Test {
	public static void main(String[] args) {
		Money m = new Money(10, "UAH");
		Money m1 = new Money(10, "UAH");
		System.out.println(m);
		System.out.println(m1);
		System.out.println(m.add(m1));
		System.out.println(m.substract(m1));
		System.out.println(m.toCurrency("USD"));
	}
}
