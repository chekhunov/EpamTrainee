package patterns.observer1;

import java.util.LinkedList;
import java.util.List;
import java.util.Observable;

/**
 * Представляет данные, об изменении которых нужно оповестить наблюдателей
 * 
 * Наблюдатели подписываются на изменения, вызывая метод addObserver(Observer)
 * на том объекте этого класса, который хотят отслеживать
 * 
 * @author engsyst
 *
 */
public class ObservableMessage extends Observable {

	// Наблюдаемые данные
	private List<String> messages = new LinkedList<>(); 
	
	// Изменяет наблюдаемые данные
	public void add(String message) {
		messages.add(message);
		
		// Чтобы наблюдатели были нотифицированы нужно установить флаг
		setChanged();
		// Известить наблюдателей
		notifyObservers(message);
	}

	public List<String> getMessages() {
		return messages;
	}

}
