package patterns.observer1;

public class Test {
    private static final int COUNT = 2;

	public static void main( String[] args ) {
		// Наблюдатели
    	Channel channel1 = new Channel("One");
    	Channel channel2 = new Channel("Two");
    	Channel channel3 = new Channel("Three");
    	
    	// Объект для наблюдения
        ObservableMessage ob = new ObservableMessage();
        ob.addObserver(channel1);
        ob.addObserver(channel2);
        ob.addObserver(channel3);
        
        // Другой объект для наблюдения
        ObservableMessage ob2 = new ObservableMessage();
        ob2.addObserver(channel1);
        ob2.addObserver(channel2);
        
        // Изменение наблюдаемых объектов
        for (int i = 0; i < COUNT; i++) {
        	ob.add("" + i);
        	ob2.add("" + i + 25);
		}
        
    }
}