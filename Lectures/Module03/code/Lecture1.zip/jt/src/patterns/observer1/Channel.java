package patterns.observer1;

import java.util.Observable;
import java.util.Observer;

// Наблюдатель. Должен быть подписан на наблюдение, вызовом метода addObserver(Observer) 
public class Channel implements Observer {

	private String name;

	public Channel() {
	}

	public Channel(String name) {
		this.name = name;
	}

	// Наблюдаемый объект вызывает этот метод во время нотификации
	@Override
	public void update(Observable o, Object arg) {
		if (o instanceof ObservableMessage) {
			// ObservableMessage subject = (ObservableMessage) o;
			System.out.println("\n" + name + ":\nObservable - " + o + "\nData ---===" + arg + "===---");
		}
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
