package patterns.factory;

//concrete factory class
public class XMLFactory implements ParserFactory {

	// factory method
	@Override
	public Parser getParser() {
		return new XMLParser();
	}
	
}
