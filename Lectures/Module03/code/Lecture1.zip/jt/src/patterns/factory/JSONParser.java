package patterns.factory;

// implementation of a known interface that will be returned by the factory method
public class JSONParser implements Parser {

	@Override
	public String parse(String msg) {
		return getClass().getSimpleName() + ": " + msg;
	}

}
