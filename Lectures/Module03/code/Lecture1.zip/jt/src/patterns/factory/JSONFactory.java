package patterns.factory;

// concrete factory class
public class JSONFactory implements ParserFactory {

	// factory method
	@Override
	public Parser getParser() {
		return new JSONParser();
	}

}
