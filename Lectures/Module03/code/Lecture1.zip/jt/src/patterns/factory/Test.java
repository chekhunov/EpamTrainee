package patterns.factory;

public class Test {
	public static void main(String[] args) {
		ParserFactory pf = Factory.getParserFactory(Factory.JSON_FACTORY);
		Parser parser = pf.getParser();
		System.out.println(parser.parse("Message"));
	}
}
