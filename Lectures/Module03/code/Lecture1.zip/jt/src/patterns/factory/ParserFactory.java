package patterns.factory;

// Specifies what methods each factory should have
public interface ParserFactory {
	Parser getParser();
}
