/*
 * Abstract factory pattern.
 * 
 * An abstract class returns its own implementation, which is a factory.
 * The returned factory class has a factory method. See factory method pattern.
 */
package patterns.factory;

public abstract class Factory implements ParserFactory {
	public static final String XML_FACTORY = "XML";
	public static final String JSON_FACTORY = "JSON";

	// returns one of its implementations, which depends on the configuration.
	static public ParserFactory getParserFactory() {
		if (Config.getConfig().equals(XML_FACTORY)) {
			return new XMLFactory();
		} else if (Config.getConfig().equals(JSON_FACTORY)) {
			return new JSONFactory();
		}
		throw new UnsupportedClassVersionError();
	}

	// returns specified implementation.
	static public ParserFactory getParserFactory(String whichFactory) {
		if (whichFactory.equals(XML_FACTORY)) {
			return new XMLFactory();
		} else if (whichFactory.equals(JSON_FACTORY)) {
			return new JSONFactory();
		}
		throw new UnsupportedClassVersionError();
	}

}

class Config {

	static public String getConfig() {
		// Read configuration
		return "XML";
	}
}