import java.util.Locale;
import java.util.Scanner;

public class Test {
	public static void main(String[] args) {
		Locale.setDefault(Locale.ENGLISH);
		System.out.println(Locale.getDefault());
		Scanner s = new Scanner("12.34 1.2");
		System.out.println(s.nextDouble());
	}
}
