public class Test2 {
	public static void main(String[] args) {
		String s = "asdf7";
		final int x = 7;
		System.out.println(s == "asdf" + x);
	}
}
