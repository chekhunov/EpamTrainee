public class Test {
	public static void main(String[] args) {
		String s = "asdf";
		final String s2 = "f";
		System.out.println(s == "asd" + s2);
	}
}
