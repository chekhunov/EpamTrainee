public class Test4 {
	public static void main(String[] args) {
		// []
		
		String s = "asdf"; 
		// ["asdf"]
		
		String s2 = s.substring(2); // 'df'
		// ["asdf"]
		
		s2.intern();
		// ["asdf", 'df']
		
		System.out.println(s2 == "df");
	}
}
