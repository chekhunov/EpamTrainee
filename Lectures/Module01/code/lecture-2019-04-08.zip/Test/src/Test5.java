public class Test5 {
	public static void main(String[] args) {
		String s = "asen"; 
		String s2 = s.substring(2);
		System.out.println(s2);
		
		System.out.println(s2 == s2.intern());
	}
}
