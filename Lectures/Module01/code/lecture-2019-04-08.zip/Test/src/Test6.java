public class Test6 {

	private static int N = 2_000_000;

	private static String str = "asdf";

	static void testString() {
		String s = "";
		long before = System.currentTimeMillis();
		for (int j = 0; j < N; j++) {
			s += str;
		}
		long after = System.currentTimeMillis();
		System.out.println(after - before);
	}

	static void testString2() {
		String s = "";
		long before = System.currentTimeMillis();
		for (int j = 0; j < N; j++) {
			s = s.concat(str);
		}
		long after = System.currentTimeMillis();
		System.out.println(after - before);
	}

	static void testStringBuilder() {
		StringBuilder sb = new StringBuilder();
		long before = System.currentTimeMillis();
		for (int j = 0; j < N; j++) {
			sb.append(str);
		}
		long after = System.currentTimeMillis();
		System.out.println(after - before);
	}

	static void testStringBuffer() {
		StringBuffer sb = new StringBuffer();
		long before = System.currentTimeMillis();
		for (int j = 0; j < N; j++) {
			sb.append(str);
		}
		long after = System.currentTimeMillis();
		System.out.println(after - before);
	}
	
	public static void main(String[] args) {
		testStringBuilder();
		testStringBuffer();
		testString2();
		testString();
	}
}
