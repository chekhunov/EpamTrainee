public class Test3 {
	public static void main(String[] args) {
		// []
		
		String s = "asdf"; 
		// ["asdf"]
		
		String s2 = s.substring(2); // 'df'
		// ["asdf"]
		
//		System.out.println(s2 == "df");
		"df".toString();
		// ["asdf", "df"]
		
		System.out.println(s2 == s2.intern());

		

	}
}
