
public class Test11 {
	
	public static void main(String[] args) {
		byte x = 127;
		
		byte y = ++x; // byte ==>byte
		
		System.out.println(y);
		
		for (byte j = 0; j < 128; j++) {
			System.out.println(j);
		}
		
		
	}

}
