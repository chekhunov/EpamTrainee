
public class Test6 {
	
	public static void main(String[] args) {
		System.out.println(2 + 3 + "asdf");
		System.out.println("asdf" + 2 + 3);
		
		double d = 0.2;
		double d2 = 0.7;
		System.out.println(d + d2);
		// BigDecimal  BigInteger
	}

}
