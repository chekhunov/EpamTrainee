
public class Test8 {
	
	public static void main(String[] args) {
		int x = 7 / 2;
		System.out.println(x);
		
		System.out.println(2 / 0);
	}

}
