
public class Test4 {
	
	public static void main(String[] args) {
		// + for integers
		System.out.println(Integer.MAX_VALUE + 1);
		
		// + for decimals
		System.out.println(Double.MAX_VALUE);
		System.out.println(
			Double.MAX_VALUE + 100_000_000);

		System.out.println(
			Double.MAX_VALUE + Double.MAX_VALUE);
	}

}
