
public class Test9 {
	
	public static void main(String[] args) {
		double x = 7 / 2.;
		System.out.println(x);

		x = 7 / 0.;
		System.out.println(x);
		
		double d = x - x;
		
		System.out.println(d == d);
		
		System.out.println(0/0.0);
	}

}
