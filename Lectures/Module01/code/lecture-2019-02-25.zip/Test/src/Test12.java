
public class Test12 {
	
	public static void main(String[] args) {
		int x = -1;
		System.out.println(Integer.toBinaryString(x));
		System.out.println(~~x);
		System.out.println(~~~x);
		
		int y = 2;
		y += 2.5; // <==> y = (int)(y + 2.5)
	}

}
