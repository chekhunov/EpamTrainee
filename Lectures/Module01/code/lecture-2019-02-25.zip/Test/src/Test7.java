
public class Test7 {
	
	public static void main(String[] args) {
		System.out.println(Float.MAX_VALUE);
//		System.out.println(Float.MAX_VALUE * 1.1);

		System.out.println(Float.MAX_VALUE * 1.0000001F);
	}

}
