
public class Test {
	
	public static void main(String[] args) {
		byte x = 7;
		byte y = x + x; // int ==X==> byte
		
		x = -x; // int ==X==> byte	
		
	}

}
