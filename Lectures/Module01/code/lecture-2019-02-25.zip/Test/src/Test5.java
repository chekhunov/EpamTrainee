
public class Test5 {
	
	public static void main(String[] args) {
		byte x = 7;
		x = +x; // +3 ==> 0 + 3
	}

}
