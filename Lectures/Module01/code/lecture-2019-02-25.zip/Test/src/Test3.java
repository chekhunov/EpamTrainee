
public class Test3 {
	
	public static void main(String[] args) {
		String s = "asdf\12ASDF";
		System.out.println(s);
	}

}
