public class Hello {
	public static void main(String[] args) {
		int x = Integer.MAX_VALUE - 10_000_000;
		System.out.println(x);
		float f = x; // int ==> float
		System.out.println(f);
		
		int x2 = (int)f;
		System.out.println(x2);
		
	}
}
