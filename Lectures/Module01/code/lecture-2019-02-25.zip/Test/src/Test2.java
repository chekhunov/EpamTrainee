
public class Test2 {
	
	public static void main(String[] args) {
		final int x = 7; 
		byte b = x; // int ==> byte
		
		int y = 7L;
		
		float f = 0.0;
		
		
		long z = 2_000_000_0000L;
		int z2 = 2_000_000_0000L;
	}

}
