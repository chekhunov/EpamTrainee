public class Test {
	public static void main(String[] args) {
		G g = new A(); // A ==> G
		g.toString();
	}
}

interface G {
	
}

class A extends Object implements G {
	
}



