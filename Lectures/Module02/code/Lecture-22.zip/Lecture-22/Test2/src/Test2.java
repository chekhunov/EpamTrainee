import java.lang.reflect.Modifier;

public class Test2 {
	
	public static void main(String[] args) {
		int m = J.class.getModifiers();
		System.out.println(Modifier.isAbstract(m));
		
		J.m3();
	}
}

// abstract
interface J {
	// before 8 version 

	// public static final
	int MY_AGE = 100;
	
	// public abstract
	void m();
	
	// public static 
	interface H {}
	
	// public static
	class B {}
	
	// since 8 version
	
	// public
	default void m2() {
		System.out.println("J#m2");
	}
	
	// public
	static void m3() {
		System.out.println("J.m3");
	}
	
	
}
