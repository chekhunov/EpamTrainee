public class Test4 {
	public static void main(String[] args) {
	}
}

interface T extends T1, T2 {

	default void m() {
		T1.super.m();
	}

}

interface T1 {
	default void m() { }
}

interface T2 {
	default void m() { }
}

