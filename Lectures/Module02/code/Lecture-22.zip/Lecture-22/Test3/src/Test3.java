public class Test3 {
	public static void main(String[] args) {
		H h = new D();
		Integer x = h.m();
	}
}

interface H {
	Integer m();
}

interface H2 {
	Number m();
}

interface R extends H, H2 {}

class D implements H, H2 {
	public Integer m() { return 23; } 
}

