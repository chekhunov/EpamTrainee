public class Test5 {
	public static void main(String[] args) {
		B2.m();
//		SImpl.m();
		S.m();

	}
}

class B {
	static void m() { System.out.println("B#m");}
}

class B2 extends B {
}

interface S {
	static void m() { System.out.println("S.m"); }
}
class SImpl implements S {}
