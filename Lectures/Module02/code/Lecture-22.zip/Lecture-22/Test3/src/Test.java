public class Test {
	public static void main(String[] args) {
	}
}

interface G2 {}

interface G3 {}

interface G extends G2, G3 {}

class A extends Thread implements G2, G3, G {}