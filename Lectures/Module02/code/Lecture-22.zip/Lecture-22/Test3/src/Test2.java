public class Test2 {
	public static void main(String[] args) {
		J j = new C();
		j.m();
		j.m2();
	}
}

interface J {
	void m();
	default void m2() { System.out.println("J#m2"); }
}

class C implements J {
	public void m() { System.out.println("C#m"); }
	public void m3() { System.out.println("C#m3"); }
}