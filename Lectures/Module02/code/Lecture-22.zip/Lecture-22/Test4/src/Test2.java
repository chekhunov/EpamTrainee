
public class Test2 {
	
	public static void main(String[] args) {
		G g = new G() {
			public void m() {
				System.out.println("Anonymous#m");
			}
			void n() { System.out.println("Anonymous#n"); }
		};
	}
	
	public static void main2(String[] args) {
		A a = new A(2) {
			void m2() {
				System.out.println("Anonymous#m");
			}			
		};
		a.m();
		Class c = a.getClass();
		System.out.println(c);
		System.out.println(c.getSuperclass());
	}
}

class A {
	A() { System.out.println("A()"); }
	A(int x) { System.out.println("A(int)"); }

	void m() { System.out.println("A#m"); }
}

interface G {
	void m();
}
