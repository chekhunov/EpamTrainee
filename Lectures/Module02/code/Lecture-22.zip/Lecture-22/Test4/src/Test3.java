
public class Test3 {
	
	public static void main(String[] args) {
		new Thread() {
			public void run() {
				while (true) {
					System.out.println(this);
					try {
						sleep(333);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}.start();
	}
}
