import static java.util.Arrays.*;

import java.util.List;

public class Test6 {

	public static void main(String[] args) {
		List list = asList(1, 2, 3);
		System.out.println(list);
	}

}
