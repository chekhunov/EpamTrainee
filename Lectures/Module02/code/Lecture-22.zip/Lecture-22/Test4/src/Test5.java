
public class Test5 {
	
	public static void main(String[] args) {

	}

}

class X {
	static int z;
	
	int x = 7;

	class Y {
		int y;
		void m() {
			y = z;
			System.out.println(x);
		}
		
	}

}


class P {
	
	static int add(int x, int y) {
		return x + y;
	}
	
}

class E {
	void m() {
		P.add(2, 3);
	}
}
