
public class Test { // top level class
	
	static class A {} // <-- nested class (member of class)

	class B {} 	// <-- internal class	
	
	void m() {
		class C {} // <-- internal local class
		C c = new C();
	}

}
