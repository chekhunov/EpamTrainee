
public class Test4 {
	
	public static void main(String[] args) {
		Outer.B b = new Outer.B();
		b.m();
		
		Outer outer = new Outer();
		Outer.A a = outer.new A();
		a.m();
		
		new Outer().new A().m();
	}

}

class Outer {
	class A {
		void m() { System.out.println("A#m"); }
	}
	
	static class B {
		void m() { System.out.println("B#m"); }
	}
}




