
public class Test {
	
	public static void main(String[] args) {
		A a = new B();
		a.m();
	}

}


abstract class A {
	
	A() {
		System.out.println("A#constr");
	}
	abstract void m();
}

class B extends A {

	B() {
		super();
		System.out.println("B#constr");
	}

	void m() {
		System.out.println("B#m");
	}
}

