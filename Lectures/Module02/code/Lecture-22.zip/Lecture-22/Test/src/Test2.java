
public class Test2 {
	
	public static void main(String[] args) {
		Class c = int[].class;
		for (Object el : c.getMethods()) {
			System.out.println(el);
		}
		System.out.println("ok");
	}

}






