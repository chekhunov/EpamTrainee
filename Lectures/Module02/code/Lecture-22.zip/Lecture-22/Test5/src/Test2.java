
public class Test2 {
	public static void main(String[] args) {
		Integer x;
		Integer x2;
		
		x = 127; 
		x2 = 127; 
		System.out.println(x == x2);

		x = 128; 
		x2 = 128; 
		System.out.println(x == x2);
		
		Double d = 0.; // int ==> Integer ==X==> Double
		Double d2 = 0.; 
		System.out.println(d == d2);
	}
}
