
public class Test3 {
	public static void main(String[] args) {
		int sum;
		long before;
		long after;
		
		int n = 100_000_000;
		sum = 0;
		before = System.currentTimeMillis();
		for (int j = 0; j < n; j++) {
			sum += j;
		}
		after = System.currentTimeMillis();
		System.out.println(after - before);

		Integer sum2 = 0;
		before = System.currentTimeMillis();
		for (Integer j = 0; j < n; j++) {
			sum2 += j;
		}
		after = System.currentTimeMillis();
		System.out.println(after - before);
	}
}
