
public class Test {
	public static void main(String[] args) {
		Integer x = 7; // int ==> Integer (auto box)
		int y = x; // Integer ==> int (auto unbox)
		// since 1.4
		
		Integer x2 = Integer.valueOf(7);
		int y2 = x2.intValue();
	}
}
