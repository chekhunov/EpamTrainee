
public class Test {
	
	public static void main(String[] args) {
		G g;

		g = new G() {
			public void m(int x, double y) {
				System.out.println("Anonymous#m " + x + y);
			}
		};
		g.m(2, 3);
		
		g = (x, y) -> System.out.println("Lambda#m " + x + y);
		g.m(2, 3);
	}
}

interface G {
	void m(int x, double y);
}
