
public class Test2 {
	
	public static void main(String[] arhg) {
		H h;

		h = new H() {
			public char m(String s, int index) {
				return s.charAt(index);
			}
		};
		System.out.println(h.m("asdf", 2));
		
		h = (s, index) -> {
				return s.charAt(index);
		};

		h = (s, index) -> s.charAt(index);
		System.out.println(h.m("asdf", 2));
		
	}
}

interface H {
	char m(String s, int index);
}
