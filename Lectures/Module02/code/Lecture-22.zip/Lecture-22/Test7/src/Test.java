
public class Test {
	
	public static void main(String[] arhg) {
		H h;
		
		String s = "ASDF";
		h = s::charAt; // instance method reference
		System.out.println(h.m(2));
		
		J j = String::charAt; // 
		System.out.println(j.m("12345", 3));
		
		j = A::asdf;
		System.out.println(j.m("qwerty", 3));

	}
}

interface H {
	char m(int index);
}

interface J {
	char m(String s, int index);
}

class A {
	static char asdf(String s, int index) {
		return s.charAt(index);
	}
}
