import java.util.Arrays;

public class Test2 {
	
	public static void main(String[] arhg) {
		G g = String::new;
		String s = g.create(new byte[] {97, 98, 99});
		System.out.println(s);
		
		G2 g2 = String::new;
		String s2 = g2.create("asdfasdfasdf");
		System.out.println(s2);
		
		R r = int[]::new;
		System.out.println(Arrays.toString(r.m(5)));

	}
}

interface G {
	String create(byte[] ar);
}

interface G2 {
	String create(String s);
}

interface R {
	int[] m(int number);
}

