import java.util.Arrays;

public class Test3 {
	
	public static void main(String[] arhg) {

	}
}


class Z {
	private interface J {
		void m();
	}
	
	class JImpl implements J {

		public void m() {
		}
		
	}
	
}