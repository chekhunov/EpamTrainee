
public class Test {
	public static void main(String[] args) {
		Parent p = new Child();
		p.m();
		
		System.out.println(new int[5] instanceof Cloneable);
		int[] ar = new int[5].clone();
	}
}

class Parent {
	void m() {
		System.out.println("Parent#m");
	}
}

class Child extends Parent {
	void m() throws Error, RuntimeException {
		System.out.println("Child#m");
	}
}

// (1) access level
// (2) result type
// (3) throws clause

// Child ==> Parent