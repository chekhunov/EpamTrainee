
public class Test2 {
	public static void main(String[] args) {
		A a = new B();
		a = null;
		a.m(); //  A.m()


	}
}

class A {
	static void m() { System.out.println("A#m"); }
}

class B extends A {
	static void m() { System.out.println("B#m"); }
}