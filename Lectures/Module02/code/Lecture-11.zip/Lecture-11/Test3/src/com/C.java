package com;

import com.my.Test;
 
class C extends Test {
	void m() {
		Test t = new Test();
 		t.x = 100;
		x = 100;
	}
}
