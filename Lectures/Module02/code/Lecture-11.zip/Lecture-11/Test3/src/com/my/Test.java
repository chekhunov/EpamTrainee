package com.my;

public class Test {
	
	public int x; 
	
	public static void main(String[] args) {
		Test t = new Test();
		t.x = 100;
	}

}

class A {
	void m() {
		Test t = new Test();
		t.x = 100;
	}
}
