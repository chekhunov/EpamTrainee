package com;

import com.my.Test;
 
class B extends Test {
	void m() {
		Test t = new Test();
// 		t.x = 100; // <-- error!!! this is wrong way!!!
		x = 100;
	}
}
