
public class Test3 {
	
	public static void main(String[] args) throws InterruptedException {
		A a = new A();
		// a --> [.....]
		
		a = null;
		// a -X-> [.....]
		
		System.gc();

//		Thread.sleep(1000);
		System.out.println("ok");
	}

}

class A {
	protected void finalize() {
		System.out.println("A#finalize");
	}
}