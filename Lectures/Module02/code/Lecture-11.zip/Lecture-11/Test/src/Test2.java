
public class Test2 {
	
	public static void main(String[] args) {
		Bird bird;
		bird = new Sparrow();
		//bird = new Pinguin();
		
		bird.fly();
		
		Class c = bird.getClass();
		System.out.println(c);
	}

}

class Bird {
	void fly() {}
}

class Sparrow extends Bird {
	void fly() {
		System.out.println("Fly away");
	}
}

class Pinguin extends Bird {
	void fly() {
		System.out.println("Fall down");
	}
}


abstract class Straus extends Bird {
	abstract void fly();
}