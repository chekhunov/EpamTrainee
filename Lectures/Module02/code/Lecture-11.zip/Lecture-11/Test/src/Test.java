public class Test {
	
	int x; // fields	
	void m() {} // methods	
	Test() {} // constructors	
	{} // init block	
	class A {} // internal classes
	
	// static components
	static int x2; // static fields	
	static void m2() {} // static methods	
	static {} // static init block	

	static class A2 {} // nested classes
	interface G {} // <-- static !!! automatically!!!
	static interface G2 {}
}
