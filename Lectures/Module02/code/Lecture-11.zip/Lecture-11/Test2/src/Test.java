public class Test {
	
	public static void main(String[] args) {
		Object c;
		c = new C();
//		c = new Object();

		System.out.println(c instanceof A);
		
		
		
	}
}

class A {}
class B extends A {}
class C extends B {}

// C ==> B ==> A
