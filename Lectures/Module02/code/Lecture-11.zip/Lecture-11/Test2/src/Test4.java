public class Test4 {
	
	public static void main(String[] args) {
		String[] ar = new String[5];
		
		ar[0] = "asdf";
//		ar[1] = 34; // <-- error!!!
		
		Object[] ar2 = ar; // String[] ==> Object[]
		ar2[0] = "asdf";
		ar2[1] = 34;
		// ArrayList<Object> list = new ArrayList<String>();
	}

}
