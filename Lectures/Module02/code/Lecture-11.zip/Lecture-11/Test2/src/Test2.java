public class Test2 {
	
	public static void main(String[] args) {
		Parent c = new Child();
		c.m();
// 		c.n(); // <-- error!!!
		
//		c = new Child2(); // <-- try to comment this line!
		
		System.out.println("~~~");
		System.out.println(c.getClass());

		if (c instanceof Child) {
			Child c2 = (Child)c; // Parent ==> Child
			c2.m();
			c2.n();
		}
		
	}
}

class Parent {
	void m() {
		System.out.println("Parent#m");
	}
}

class Child extends Parent {
	void n() {
		System.out.println("Child#n");
	}
}

class Child2 extends Parent {
	void n() {
		System.out.println("Child2#n");
	}
}

