public class Test3 {
	
	public static void main(String[] args) {
		Object o = "asdf"; // String ==> Object
		
		Object[] ar = new String[5];
		// String[] ==> Object[]
		
//		long[] ar2 = new int[5]; // <-- error!!!
		// int ==> long
		// int[] ==X==> long[]
	}

}
