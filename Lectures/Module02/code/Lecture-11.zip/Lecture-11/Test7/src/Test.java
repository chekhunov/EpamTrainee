
public class Test {
	
	public static void main(String[] args) {
		new A();
	}

}

class A {
	{ System.out.println("init Block"); }
	int x = m();
	
	int m() {
		System.out.println("A#m");
		return 0;
	}
}

class B extends A {}