
public class Test3 {
	int x;

	public void setX(int x) {
		this.x = x;
	}
	
	Test3() {
		this(0);
	}
	
	Test3(int x) {
		super();
	}
	
	class Z {
		void m() {
			System.out.println(this);
			System.out.println(Test3.this);
		}
	}
	
	public static void main(String[] args) {
		Test3 t = new Test3();
		Z z = t.new Z();
		z.m();
		
		new R().m();
	}
	
}

class T {
	void m() {System.out.println("T#m");}
}

class R extends T {
	void m() {
		super.m();
	}
}