
public class Test2 {
	
	public static void main(String[] args) {
		new Parent();
		System.out.println("~~~");
		new Child();
	}

}

class Parent {
	static { System.out.println("Parent static init"); }
	{ System.out.println("Parent init"); }
	Parent() { System.out.println("Parent#constr"); }
}

class Child extends Parent {
	static { System.out.println("Child static init"); }
	{ System.out.println("Child init"); }
	Child() { System.out.println("Child#constr"); }
}

// Z ==> Y ==> .... ==> B ==> A
// new Z()
