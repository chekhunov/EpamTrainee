
public class Test {
	
	static void m(Object o) { System.out.println("A"); }
	static void m(float x) { System.out.println("B"); }
	
	static void n(int x, double y) {}
	static void n(double x, int y) {}

	
	public static void main(String[] args) {
		byte b = 7;
		m(b);
		
//		n(1, 1);
	}

}
