// (1) class
// (2) method
// (3) static method
// (4) field
// (5) local variables
// (6) local variables

public class Test2 {
	
//	final int x = 1; 	// (1)
//	Test2() { x = 7; } 	// (2)
//	{ x = 7; }			// (3)

//	static final int x = 1; // (1)
//	static { x = 7; } 		// (2)
	
	public static void main(final String[] args) {
// 		args = null; // error!!!
	}
	
}

class Parent {
	void m() {
		final int x;
		x = 7;
//		x = x; // <-- error!!!
	}
}

class Child extends Parent {
	void m() {}
}