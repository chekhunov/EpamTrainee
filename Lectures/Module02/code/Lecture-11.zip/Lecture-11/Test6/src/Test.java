
public class Test {
	public static void main(String[] args) {
		A a = new B();
		System.out.println(a.x);
	}
}

class A {
	int x = 7;
}

class B extends A {
	int x = 8;
}