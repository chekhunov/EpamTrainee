
public class Test4 {
	
	public static void main(String[] args) throws ClassNotFoundException {
		String s = "asdf";
		
		Class c = s.getClass();
		Class c2 = String.class;
		Class c3 = Class.forName("java.lang.String");
		
		System.out.println(c == c2);
		System.out.println(c == c3);
		
	}

}