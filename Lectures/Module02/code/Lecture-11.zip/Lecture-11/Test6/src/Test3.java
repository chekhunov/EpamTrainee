
public class Test3 {
	
	public static void main(String[] args) {
		String s = "asdf";
		
		Class c = s.getClass();
		for (Object el : c.getDeclaredMethods()) {
			System.out.println(el);
		}
	}

}