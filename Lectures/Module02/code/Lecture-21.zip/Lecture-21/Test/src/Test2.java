
public class Test2 {
}

abstract class A {
	
	abstract void m();
	
	void m2() {
		m();
	}
	
	class AImpl extends A {
		void m() {
			System.out.println("AImpl#m");
		}
	}
	
//	static A getA() { return new A().new AImpl(); }
	
}