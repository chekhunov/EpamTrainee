
public class Test {
	public static void main(String[] args) {
		Sparrow bird = new Sparrow();
	}

}

abstract class Bird {
	Bird() {
		System.out.println("Bird#constr");
	}
	abstract void fly();
}

class Sparrow extends Bird {
	
	Sparrow() {
		super();
		System.out.println("Sparrow#constr");
	}

	void fly() {
		System.out.println("Fly away");
	}


}
