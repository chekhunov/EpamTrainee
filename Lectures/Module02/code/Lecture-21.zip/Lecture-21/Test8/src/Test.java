
public class Test {
	public static void main(String[] args) {
		G g = new G() {
			public char m(String s, int index) {
				return s.charAt(index);
			}	
		};
		System.out.println(g.m("asdf", 2));
		
		g = (s, index) -> s.charAt(index);
		System.out.println(g.m("asdf", 2));

		g = String::charAt; 
		System.out.println(g.m("asdf", 2));

		g = B::n; 
		System.out.println(g.m("asdf", 2));

	}
}


interface G {
	char m(String s, int index);
}

class B {
	static char n(String s, int index) {
		return s.charAt(index);
	}
}
