import java.util.Arrays;

public class Test {
	public static void main(String[] args) {
		G g = new G() {
			@Override
			public String m(byte[] bytes) {
				return new String(bytes);
			}
		};
		System.out.println(g.m(new byte[] {97, 98}));

		g = String::new;
		System.out.println(g.m(new byte[] {97, 98}));
		
		H h = int[]::new; 
		System.out.println(
				Arrays.toString(h.m(7)));

	}
}


interface G {
	String m(byte[] bytes);
}

@FunctionalInterface
interface H {
	int[] m(int x);
}

class T {
	void m(int x) {
		char ch = (char)x;
	}
}
