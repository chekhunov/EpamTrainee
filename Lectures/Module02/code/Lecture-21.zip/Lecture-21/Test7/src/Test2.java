
public class Test2 {
	public static void main(String[] args) {
		H g;
		
		g = new H() {
			public void m(int x) {
				System.out.println("Anonymous#m " + x);
			}
		};
		g.m(123);
	
		g = (int x) -> {
			System.out.println("Lambda#m " + x);
		};
		g.m(123);

		g = (x) -> System.out.println("Lambda#m " + x);
		g.m(123);
	}

}


interface H {
	void m(int x);
}


class B implements H {
	public void m(int x) {}
}
