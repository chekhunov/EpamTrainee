
public class Test {
	public static void main(String[] args) {
		G g;
		
		g = new G() {
			public void m() {
				System.out.println("Anonymous#m");
			}
		};
		g.m();
	
		g = () -> {
			System.out.println("Lambda#m");
		};
		g.m();

		g = () -> System.out.println("Lambda#m");
		g.m();
	}
}


interface G {
	void m();
}


class A implements G {
	public void m() {}
}
