
public class Test3 {
	public static void main(String[] args) {
		R g;
		
		g = new R() {
			public int m(int x, int y) {
				return x + y;
			}
		};
		System.out.println(g.m(2, 3));
		
		g = (x, y) -> x + y;
		System.out.println(g.m(1, 2));
	
	}

}


interface R {
	int m(int x, int y);
}
