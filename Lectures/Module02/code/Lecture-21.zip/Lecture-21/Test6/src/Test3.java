
public class Test3 {

	public static void main(String[] args) {
		Integer x = 7;
		Integer x2 = 7;
		
		System.out.println(x == x2);

		x = 128;
		x2 = 128;
		System.out.println(x == x2);
	}

}
