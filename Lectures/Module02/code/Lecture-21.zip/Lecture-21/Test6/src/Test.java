
public class Test {
	public static void main(String[] args) {
		
		Integer x2 = 7; // int ==autobox==> Integer
		Long x3 = 7; // int ==> Integer ==X==> Long
		
		
		long x = x2; // Integer ==auto unbox==> int

	}
}
