
public class Test2 {

	public static void main(String[] args) {
		int n = 100_000_000;

		long before;
		long after;
		int s = 0;

		before = System.currentTimeMillis();
		for (int j = 0; j < n; j++) {
			s += j;
		}
		after = System.currentTimeMillis();
		System.out.println(after - before);
		
		System.out.println("~~~");

		Integer s2 = 0;

		before = System.currentTimeMillis();
		for (Integer j = 0; j < n; j++) {
			s2 += j;
		}
		after = System.currentTimeMillis();
		System.out.println(after - before);

	}

}
