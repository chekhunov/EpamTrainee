import java.sql.SQLException;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;

public class Test2 {

	static void print(Iterable x) {
		// x.iterator
		for (Object element : x) {
			System.out.println(element);
		}
	}

	public static void main(String[] args) {
		Collection x = new HashSet();
		x.add(1);
		x.add(2);
		x.add(3);

		print(x);

		print(new SQLException());
		print(new Z());
	}

}

class Z implements Iterable {

	public Iterator iterator() {
		return null;
	}
}
