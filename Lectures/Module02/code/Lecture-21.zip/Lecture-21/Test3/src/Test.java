
public class Test {
	
	static void test(G a) {
		a.m();
	}
	
	public static void main(String[] args) {
		G g = new A(); //  A ==> G
		A a = new A();
		
		g.m();
		
		test(a);
		test(new A2());
	}

}

interface G {
	void m();
}

class A implements G {
	public void m() {
		System.out.println("A#m");
	}

	public void m2() {
		System.out.println("A#m2");
	}
}

class A2 implements G {
	public void m() {
		System.out.println("A2#m");
	}

	public void m2() {
		System.out.println("A2#m2");
	}
}
