
public class Test2 {
	public static void main(String[] args) {
		D.B b = new D.B();
		b.m();
		
		D d = new D();
		D.A a = d.new A(); 
		a.m();
	}
}

class D {
	int x;

	class A {
		void m() {
			System.out.println("A#m");
			System.out.println(x);
		}
	}

	static class B {
		void m() {
			System.out.println("B.m");
		}
	}
}
