
public class Test {
	public static void main(String[] args) {
		Class c = new A() {}.getClass();
		for (Object el : c.getDeclaredConstructors()) {
			System.out.println(el);
		}
	}
}

class A {
	
}
