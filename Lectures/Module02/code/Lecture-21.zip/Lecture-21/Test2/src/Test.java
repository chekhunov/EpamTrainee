
public class Test {
	public static void main(String[] args) {
//		System.out.println(new int[0] instanceof Cloneable);
//		Cloneable c = new int[0];
	
		GImpl gImpl = new GImpl();
		gImpl.n();
		
		
		G g = new GImpl(); 
		g.m();
		G.m2();
		System.out.println("~~~");
		g.m3();
		
	}

}

// abstract
interface G {
	// before 8 version

	// public static final
	int MY_AGE = 17;
	
	// public abstract
	void m();

	// public static 
	interface H {}

	// public static 
	class B {}
	
	// since 8 version

	// public
	static void m2() { System.out.println("G.m2"); }
	
	default void m3() { System.out.println("G#m3"); }
	
}


class GImpl extends Object implements G {
	
	static void n() {}

	public void m() {
		System.out.println("GImpl#m");
	}
	
	@Override
	public void m3() {
		G.super.m3();
		System.out.println("GImpl#m3");
	}
	
}