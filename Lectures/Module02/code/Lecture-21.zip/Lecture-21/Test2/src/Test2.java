
public class Test2 {
	public static void main(String[] args) {

	}

}

class A {
	void m() {}
}

class B extends A {
	void n() {
		m();
		super.m();
//		A.super.m(); // <-- error!!!
	}
}