
public class Test4 {
	public static void main(String[] args) {
	}

}

interface R {
	String m();
}

interface R2 {
	Integer m();
}

class C implements R, R2 {

	@Override
	public Integer m() {
		// TODO Auto-generated method stub
		return null;
	}
}
