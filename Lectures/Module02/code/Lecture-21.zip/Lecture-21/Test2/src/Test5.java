import java.lang.reflect.Modifier;

public class Test5 {
	public static void main(String[] args) {
		int mod = H.A.class.getModifiers();
		System.out.println(Modifier.isAbstract(mod));

		mod = H.class.getModifiers();
		System.out.println(Modifier.isAbstract(mod));
		
	}

}

interface H {
	class A {} // <-- abstract ???
}

