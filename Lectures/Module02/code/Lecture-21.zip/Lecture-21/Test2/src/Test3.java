
public class Test3 {
	public static void main(String[] args) {
		J2 j = new C();
		j.m();
	}

}

interface J {
	Number m();
}

interface J2 {
	Integer m();
}

class C implements J, J2 {
	public Integer m() {
		System.out.println("C#m");
		return null;
	}
}