
public class Test2 {
	
	public static void main(String[] args) {
		A a = new A() {
			void m() {
				System.out.println("Anonymous#m");
				super.m();
			}
		};
		
		a.m();
		
		Class c = a.getClass();
		System.out.println(c);
		System.out.println("~~~");
		Test2$1 x = new Test2$1();
		x.n();
	}

}

class A {
	void m() { System.out.println("A#m"); }
}

interface G {
	void m();
}


class Test2$1 {
	void n() {}
}