
public class Test {
	
	static class A {} // <-- nested class 
	
	class B {} // <-- internal class (member of top level class)
	
	void m() {
		class C {} // <-- local (internal) class
		C c = new C();
		
		// anonymous class
	}
	
}

