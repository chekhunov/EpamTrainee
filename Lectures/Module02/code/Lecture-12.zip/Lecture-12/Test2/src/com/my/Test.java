package com.my;

// private default protected public
public class Test {

//	private int x; 
//	int x; 
//	protected int x; 
	public int x; 
	
	void m() {
		Test t = new Test();
		t.x = 100;
	}

}

class A {
	void m() {
		Test t = new Test();
		t.x = 100;
	}
}
