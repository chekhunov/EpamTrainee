
public class Test3 {
	
	
	class C {
		void m() {
			System.out.println(this);
			System.out.println(Test3.this);
		}
	}
	
	
	
	public Test3() {
		this(3);
	}
	
	Test3(int x) {
		super();
	}
	
	int x;

	public void setX(int x) {
		this.x = x;
		System.out.println(this);
	}
	
	public static void main(String[] args) {
		new Test3().setX(0);
	}
	
	

}
