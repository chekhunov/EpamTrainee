
public class Test {

	public static void main(String[] args) {
		new A2();
	}
}

class A2 {
	{ System.out.println("init"); }

	int x = m();
	
	int m() {
		System.out.println("A2#m");
		return 0;
	}
}
