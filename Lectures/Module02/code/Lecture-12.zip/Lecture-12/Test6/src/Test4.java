
public class Test4 {
	public static void main(String[] args) {
		new S().m();
	}
}

class R {
	int x = 777;

	void m() {
		System.out.println("R#m");
	}
}

class S extends R {
	int x = 7;

	void m() {
		System.out.println("S#m");
		System.out.println(x);
		
		super.m();
		System.out.println(super.x);

	}
}