
public class Test2 {

	public static void main(String[] args) {
		new A();
		System.out.println("~~~");
		new B();
	}
}

// Z ==> Y ==> ... ==> B ==> A
// new Z();

class A {
	static { System.out.println("A static init"); }
	{ System.out.println("A init"); }
	A() { System.out.println("A constr"); }
}

class B extends A {
	static { System.out.println("B static init"); }
	{ System.out.println("B init"); }
	B() { System.out.println("B constr"); }
}



