
public class Test3 {
	
	public static void main(String[] args) {
	}
}

class D {
//	final int x = 7; 
//	final int x; A() { x = 7; }
//	final int x; { x = 7; }

//	static final int x = 7; 
//	static final int x; static { x = 7; }

}



