
public class Test2 {

	public static void main(String[] args) {
		A a = new B();
		System.out.println(a.x);
	}
}

class A {
	int x = 7;
}

class B extends A {
	int x = 8;
}

/*
 * (1) access level 
 * (2) return types 
 * (3) throws clause
 */