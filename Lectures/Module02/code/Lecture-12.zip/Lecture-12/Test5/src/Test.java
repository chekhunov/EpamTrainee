
public class Test extends Object {

	public static void main(String[] args) {
		Parent p = new Child();
		p = null;
		p.m(); // Parent.m();
		System.out.println("ok");
	}
}

class Parent {
	static void m() { System.out.println("Parent#m"); }
}

class Child extends Parent {
	static void m() { System.out.println("Child#m"); }
}

/*
 * (1) access level 
 * (2) return types 
 * (3) throws clause
 */