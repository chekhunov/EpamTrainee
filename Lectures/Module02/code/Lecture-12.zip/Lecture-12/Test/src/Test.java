
public class Test {
	
	int x; 		//  fields
	void m() {} // methods
	Test() {} 	// constructors
	{ }			// initialized block
	class A {} 	// internal classes
	
	// static components

	static int x2; 		//  fields
	static void m2() {} // methods
	static { }			// initialized block
	static class A2 {} 	// nested classes

	interface G {}		// nested interfaces
	static interface G2 {}		// nested interfaces
	
}
