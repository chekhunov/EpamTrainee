import java.lang.reflect.Modifier;

public class Test6 {

	private interface G {}

	public static void main(String[] args) {
		Class c = G.class;
		
		int m = c.getModifiers();
		System.out.println(Modifier.isPrivate(m));
		System.out.println(Modifier.isStatic(m));
		System.out.println(Modifier.isAbstract(m));
 	}

}


