
public class Test3 {

	public static void main(String[] args) {
		A a = new A();
		// a --> [........]
		
		a = null;
		// a -X-> [........]
		
		System.gc();

		System.out.println("ok");
		
 	}

}

class A {
	protected void finalize() {
		System.out.println("A#finalize");
	}
}
