
public class Test2 {

	public static void main(String[] args) {
		String s = "asdf";
		System.out.println(s.charAt(2));
		
		Class c = s.getClass();
		
		for (Object el : c.getDeclaredMethods()) {
			System.out.println(el);
		}
		
		c = int[].class; 
		c = int.class;

	}

}
