
public class Test4 {

	public static void main(String[] args) {
		S s = new S();
		s.m();
 	}

}

class R {
	void m() { System.out.println("R#m"); }
}

// S ==> R ==> Object
class S extends R {
	
}