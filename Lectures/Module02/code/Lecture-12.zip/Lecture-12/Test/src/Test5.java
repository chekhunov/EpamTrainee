
public class Test5 {

	static void test(Bird bird) {
		bird.fly();
	}
	
	public static void main(String[] args) {
		test(new Penguin());
		test(new Sparrow());
		
		Bird b;
		b = new Penguin();
		b = new Sparrow();
 	}

}

class Bird {
	void fly() {}
}

class Sparrow extends Bird {
	void fly() {
		System.out.println("Fly away");
	}
}

class Penguin extends Bird {
	void fly() {
		System.out.println("Fall down");
	}
}




/*
Bird
	Sparrow
	Pinguin
		
*/