import java.util.ArrayList;

public class Test3 extends Object {
	
	public static void main(String[] args) {
		String s = "asdf";
		Object o = s; // String ==> Object
		
		String[] ar = new String[5];
		ar[0] = "asdf";
//		ar[1] = 7;
		// ar --> [.......]
		Object[] ar2 = ar; // String[] ==> Object[]
		ar2[1] = 7;
		
	}

	public static void main2(String[] args) {
		// B ==> A
		// B[] ==> A[]
		int x = 7;
		long y = x; // int ==> long
// 		long[] ar = new int[5]; // <-- error!!!
	}
}
