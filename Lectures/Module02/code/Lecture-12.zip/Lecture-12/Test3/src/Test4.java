
public class Test4 {

	static void m(float x) { System.out.println("A"); }
	static void m(Object x) { System.out.println("B"); }
	
	static void n(int x, double y) {}
	static void n(double x, int y) {}

	public static void main(String[] args) {
		byte x = 7;
		m(x);
		
	//	n(1, 1); // <-- error!!!
	}

}
	
