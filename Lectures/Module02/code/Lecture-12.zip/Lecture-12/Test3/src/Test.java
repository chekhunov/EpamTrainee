
public class Test extends Object {
	
	public static void main(String[] args) {
		Object obj;
		obj = new B();
		obj = new A();
		obj = "asdf";
		obj = new Object[5];
		obj = new int[2];
		obj = new long[2][2];
		obj = new Test();

		System.out.println(obj instanceof B);
		System.out.println(obj instanceof A);
		System.out.println(obj instanceof Object);
		System.out.println("~~~");
		System.out.println(obj.getClass());
		System.out.println(obj);
	}
}

class A {
	
}

class B extends A {
	
}