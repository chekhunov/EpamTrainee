
public class Test2 extends Object {
	
	public static void main(String[] args) {
		Child c = new Child();
		Parent p = c; // Child ==> Parent
//		p = new Child2();
	
		if (p instanceof Child) {
			c = (Child)p; // Parent ==> Child
			c.m();
			c.n();
		}
		
		System.out.println("ok");
	}
}

class Parent {
	void m() { System.out.println("Parent#m"); }
}

class Child extends Parent {
	void n() { System.out.println("Child#n"); }
}

class Child2 extends Parent {
	void n2() { System.out.println("Child2#n"); }
}