import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Test3 {

	private static final String CONNECTION_URL = 
			"jdbc:mysql://localhost:3306/testdb"
			+ "?user=testuser&password=testpass";

	private static final String SQL_SELECT_ALL_USERS =
			"SELECT * FROM users";
	
	
	public static List<User> findAllUsers() throws SQLException {
		List<User> users = new ArrayList<>();
		Connection con = DriverManager.getConnection(CONNECTION_URL);
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(SQL_SELECT_ALL_USERS);
		while (rs.next()) {
			int id = rs.getInt("id");
			String login = rs.getString("login");
			User user = new User();
			user.setId(id);
			user.setLogin(login);
			users.add(user);
		}
		con.close(); // <--  tomcat documentation
		return users;
	}

	public static void main(String[] args) throws SQLException {
		findAllUsers().forEach(System.out::println);
	}

}
