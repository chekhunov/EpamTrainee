import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Test2 {

	private static final String CONNECTION_URL = 
			"jdbc:mysql://localhost:3306/testdb"
			+ "?user=testuser&password=testpass";

	private static final String SQL_SELECT_ALL_USERS =
			"SELECT * FROM users";

	public static void main(String[] args) throws SQLException {
		// (1) obtain a connection
		Connection con = DriverManager.getConnection(CONNECTION_URL);
		System.out.println(con);
		
		// (2) create a statement
		Statement stmt = con.createStatement();
		
		// (3) make a query
		ResultSet rs = stmt.executeQuery(SQL_SELECT_ALL_USERS);
		
		while (rs.next()) {
		//	int id = rs.getInt("id");
			String login = rs.getString("login");
			System.out.println(login);
		}
		
		con.close(); // <--  tomcat documentation
		
	}

}
