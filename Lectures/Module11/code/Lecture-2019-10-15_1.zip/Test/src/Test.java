import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Test {
	
	private static final String URL = 
		"jdbc:mysql://localhost:3306/"
		+ "testdb?user=testuser&password=testpass";

	private static final String SQL_FIND_ALL_USER =
			"SELECT * FROM users";

	public static void main(String[] args) throws SQLException {
		// (1)
		Connection con = DriverManager.getConnection(URL);
		System.out.println("con = " + con);
		
		// (2)
		Statement stmt = con.createStatement();
		
		// (3)
		ResultSet rs = stmt.executeQuery(SQL_FIND_ALL_USER);
		
		// (4)
		while (rs.next()) {
			int id = rs.getInt("id"); // Fields.USERS_ID
			String login = rs.getString("login"); // Fields.USERS_LOGIN
			
			User user = new User();
			user.setId(id);
			user.setLogin(login);
			
			System.out.println(user);
		} 

	}
		

}
