import java.sql.SQLException;

import db.DBManager;
import db.entity.User;

public class Test {

	public static void main(String[] args) throws SQLException {
		DBManager dbManager = DBManager.getInstance();
		
		User user1 = new User();
		user1.setLogin("Bush");

		User user2 = new User();
		user2.setLogin("Bush2");
		
		System.out.println(dbManager.insertTwoUser(user1, user2));

		
		
	}

}
