import java.sql.SQLException;

import db.DBManager;
import db.entity.User;

public class Test {

	public static void main(String[] args) throws SQLException {
		DBManager dbManager = DBManager.getInstance();

		dbManager.findAllUsers().forEach(System.out::println);
		
		System.out.println("~~~~");
		
		System.out.println(dbManager.findUserByLogin("admin"));
		System.out.println(dbManager.findUserByLogin("admin2"));

		System.out.println("~~~~");
		
		
		User user = new User(); // id = 0 (default value)
		user.setLogin("Obama2");
		
		//dbManager.insertUser(user); 
//		System.out.println(user); // id = 8

		System.out.println("~~~~");
		
		user.setId(9);
		user.setLogin("Trump");
		dbManager.updateUser(user);  // id login    

		dbManager.findAllUsers().forEach(System.out::println);
		
		System.out.println("~~~");
		
		dbManager.deleteUser(user.getId());
		dbManager.findAllUsers().forEach(System.out::println);
		
		
	}

}
