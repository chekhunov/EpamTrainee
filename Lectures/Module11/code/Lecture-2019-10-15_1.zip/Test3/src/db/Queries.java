package db;

public class Queries {
	
	private Queries() {}
	

}
