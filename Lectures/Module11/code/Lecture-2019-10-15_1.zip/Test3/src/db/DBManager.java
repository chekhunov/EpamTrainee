package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import db.entity.User;

public class DBManager {
	
	////////////// Singleton
	
	private static DBManager instance;
	
	public static synchronized DBManager getInstance() {
		if (instance == null) {
			instance = new DBManager();
		}
		return instance;
	}
	
	private DBManager() {
		// ...
	}

	//////////////
	
	
	private static final String URL = 
		"jdbc:mysql://localhost:3306/"
		+ "testdb?user=testuser&password=testpass";

	private static final String SQL_FIND_ALL_USER =
			"SELECT * FROM users";

	private static final String SQL_FIND_USER_BY_LOGIN = 
			"SELECT * FROM users WHERE login=?";

	private static final String SQL_INSERT_USER = 
			"INSERT INTO users VALUES (DEFAULT, ?)";

	private static final String SQL_UPDATE_USER = 
			"UPDATE users SET login=? WHERE id=?";

	private static final String SQL_DELETE_USER = 
			"DELETE FROM users WHERE id=?";

	public List<User> findAllUsers() {
		List<User> users = new ArrayList<>();
		
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			con = DriverManager.getConnection(URL);
			stmt = con.createStatement();
			rs = stmt.executeQuery(SQL_FIND_ALL_USER);
			while (rs.next()) {
				users.add(extractUser(rs));
			} 
		} catch (SQLException ex) {
			ex.printStackTrace(); // write to LOGGER
		} finally {
			close(con);
		}
		return users;
	}
	
	public User findUserByLogin(String login) { 
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DriverManager.getConnection(URL);
			pstmt = con.prepareStatement(SQL_FIND_USER_BY_LOGIN);

			pstmt.setString(1, login);

			rs = pstmt.executeQuery();
			if (rs.next()) {
				return extractUser(rs);
			} 
		} catch (SQLException ex) {
			ex.printStackTrace(); // write to LOGGER
		} finally {
			close(con);
		}
		return null;
	}

	public boolean insertUser(User user) {  // id login
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DriverManager.getConnection(URL);
			pstmt = con.prepareStatement(SQL_INSERT_USER,
					Statement.RETURN_GENERATED_KEYS);

			pstmt.setString(1, user.getLogin());

			if (pstmt.executeUpdate() > 0) {
				rs = pstmt.getGeneratedKeys();
				if (rs.next()) {
					user.setId(rs.getInt(1));
				}
				return true;
			}
		} catch (SQLException ex) {
			ex.printStackTrace(); // write to LOGGER
		} finally {
			close(con);
		}
		return false;
	}

	public boolean updateUser(User user) {  // id login
		boolean result = false;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DriverManager.getConnection(URL);
			pstmt = con.prepareStatement(SQL_UPDATE_USER);
				
			int k = 1;
			pstmt.setString(k++, user.getLogin());
			pstmt.setInt(k++, user.getId());

			result = pstmt.executeUpdate() > 0;
		} catch (SQLException ex) {
			ex.printStackTrace(); // write to LOGGER
		} finally {
			close(con);
		}
		return result;
	}

	public boolean deleteUser(int userId) {  // id login
		boolean result = false;
		
		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DriverManager.getConnection(URL);
			pstmt = con.prepareStatement(SQL_DELETE_USER);
				
			int k = 1;
			pstmt.setInt(k++, userId);

			result = pstmt.executeUpdate() > 0;
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(con);
		}
		return result;
	}

	////////////////// Utils methods
	private User extractUser(ResultSet rs) throws SQLException {
		User user = new User();
		user.setId(rs.getInt("id"));
		user.setLogin(rs.getString("login"));
		return user;
	}
	
	
	private static void close(Connection con) {
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace(); // write to LOGGER
			}
		}
	}

}
