package db.logic;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import db.DBException;
import db.entity.User;

public class UserManager {
	
	public boolean insertTwoUser(User user1, User user2) throws DBException {
		Connection con = null;

		try {
			con = DriverManager.getConnection(URL);
			
			con.setAutoCommit(false);
			con.setTransactionIsolation(Connection.TRANSACTION_READ_COMMITTED);

			boolean result = insertUser(con, user1) && insertUser(con, user2);
			con.commit();
			return result;
		} catch (SQLException ex) {
			// (1) 
			rollback(con);
			
			// (2) write to logger
			ex.printStackTrace(); 
			
			// (3) 
			throw new DBException("Cannot insert two users", ex);
		} finally {
			close(con);
		}
	}

}
