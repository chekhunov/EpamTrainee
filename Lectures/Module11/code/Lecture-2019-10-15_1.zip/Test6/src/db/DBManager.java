package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import db.entity.User;

public class DBManager {
	
	////////////// Singleton
	
	private static DBManager instance;
	
	public static synchronized DBManager getInstance() {
		if (instance == null) {
			instance = new DBManager();
		}
		return instance;
	}
	
	private DBManager() {
		// ...
	}

	//////////////
	
	
	private static final String URL = 
		"jdbc:mysql://localhost:3306/"
		+ "testdb?user=testuser&password=testpass";


	private static final String SQL_INSERT_USER = 
			"INSERT INTO users VALUES (DEFAULT, ?)";




	public boolean insertUser(Connection con, User user) throws SQLException {
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			pstmt = con.prepareStatement(SQL_INSERT_USER,
					Statement.RETURN_GENERATED_KEYS);

			pstmt.setString(1, user.getLogin());

			if (pstmt.executeUpdate() > 0) {
				rs = pstmt.getGeneratedKeys();
				if (rs.next()) {
					user.setId(rs.getInt(1));
				}
				return true;
			}
		} finally { 
			close(rs);
			close(pstmt);
		}
		return false;
	}


	////////////////// Utils methods
	private User extractUser(ResultSet rs) throws SQLException {
		User user = new User();
		user.setId(rs.getInt("id"));
		user.setLogin(rs.getString("login"));
		return user;
	}
	
	
	private static void close(Connection con) {
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace(); // write to LOGGER
			}
		}
	}

	private static void close(Statement stmt) {
		if (stmt != null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace(); 
			}
		}
	}

	private static void close(ResultSet rs) {
		if (rs != null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace(); 
			}
		}
	}

	private static void rollback(Connection con) {
		if (con != null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace(); 
			}
		}
	}

}
