package db;

import java.sql.SQLException;

public class DBException extends Exception {

	public DBException(String message, Exception cause) {
		super(message, cause);
	}

}
