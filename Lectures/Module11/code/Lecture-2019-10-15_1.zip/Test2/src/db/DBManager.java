package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import db.entity.User;

public class DBManager {
	
	////////////// Singleton
	
	private static DBManager instance;
	
	public static synchronized DBManager getInstance() {
		if (instance == null) {
			instance = new DBManager();
		}
		return instance;
	}
	
	private DBManager() {
		// ...
	}

	//////////////
	
	
	private static final String URL = 
		"jdbc:mysql://localhost:3306/"
		+ "testdb?user=testuser&password=testpass";

	private static final String SQL_FIND_ALL_USER =
			"SELECT * FROM users";

	public List<User> findAllUsers() throws SQLException {
		List<User> users = new ArrayList<>();
		
		Connection con = DriverManager.getConnection(URL);
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(SQL_FIND_ALL_USER);
		while (rs.next()) {
			int id = rs.getInt("id");
			String login = rs.getString("login"); 
			
			User user = new User();
			user.setId(id);
			user.setLogin(login);
			
			users.add(user);
		} 
		con.close(); 
		return users;
	}

}
