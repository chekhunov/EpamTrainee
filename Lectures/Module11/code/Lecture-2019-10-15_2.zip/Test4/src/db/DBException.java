package db;

public class DBException extends Exception {

	public DBException(String message, Exception ex) {
		super(message, ex);
	}

}
