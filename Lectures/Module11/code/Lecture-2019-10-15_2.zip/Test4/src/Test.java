import java.sql.SQLException;

import db.DBException;
import db.DBManager;
import db.entity.User;

public class Test {
	
	public static void main(String[] args) throws SQLException {
		DBManager dbManager = DBManager.getInstance();

		dbManager.findAllUsers().forEach(System.out::println);

		System.out.println("~~~");
		
		User user = new User();
		user.setLogin("trump");
		user.setPassword("trumppass");

		User user2 = new User();
		user2.setLogin("bush2");
		user2.setPassword("bush2pass");
		
		try {
			dbManager.insertUsers(user, user2);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}

	}


}
