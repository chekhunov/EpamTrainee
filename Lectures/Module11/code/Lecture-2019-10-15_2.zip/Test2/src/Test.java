import java.sql.SQLException;

import db.DBManager;
import db.entity.User;

public class Test {
	
	public static void main(String[] args) throws SQLException {
		DBManager dbManager = DBManager.getInstance();

		dbManager.findAllUsers().forEach(System.out::println);
		
		System.out.println("~~~");

		System.out.println(dbManager.findUserByLogin("admin"));
		System.out.println(dbManager.findUserByLogin("admin2"));

		System.out.println("~~~");
		
		User user = new User();
		user.setLogin("bush");
		user.setPassword("bushpass");
		
//		System.out.println(dbManager.insertUser(user));
		
		System.out.println(user);

		System.out.println("~~~");
		
		user = new User();
		user.setId(9);
		user.setLogin("bush2");
		user.setPassword("bush2pass");
		System.out.println(dbManager.updateUser(user));
		dbManager.findAllUsers().forEach(System.out::println);
		
		System.out.println("~~~");
		dbManager.deleteUser(user.getId());

		dbManager.findAllUsers().forEach(System.out::println);

	}


}
