package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import db.entity.User;

public class DBManager {

	// =================== singleton

	private static DBManager instance;

	public static synchronized DBManager getInstance() {
		if (instance == null) {
			instance = new DBManager();
		}
		return instance;
	}

	private DBManager() {
		// ...
	}

	// =================== singleton

	private static final String URL = "jdbc:mysql://localhost:3306/testdb" + "?user=testuser&password=testpass";

	private static final String SQL_FIND_ALL_USERS = "SELECT * FROM users";

	private static final String SQL_FIND_USER_BY_LOGIN = "SELECT * FROM users WHERE login=?"; // StringBuilder

	private static final String SQL_INSERT_USER = "INSERT INTO users VALUES (DEFAULT, ?, ?)";

	private static final String SQL_UPDATE_USER = 
			"UPDATE users SET login=?, password=? WHERE id=?";

	private static final String SQL_DELETE_USER = 
			"DELETE FROM users WHERE id=?";

	public List<User> findAllUsers() throws SQLException {
		List<User> users = new ArrayList<>();

		Connection con = DriverManager.getConnection(URL);
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(SQL_FIND_ALL_USERS);
		while (rs.next()) {
			users.add(extractUser(rs));
		}

		rs.close();
		stmt.close();
		con.close(); // tomcat apache
		return users;
	}

	public boolean deleteUser(int userId) throws SQLException {
		boolean result = false;

		Connection con = DriverManager.getConnection(URL);
		PreparedStatement pstmt =
			con.prepareStatement(SQL_DELETE_USER);

		int k = 1;
		pstmt.setInt(k++, userId);

		result = pstmt.executeUpdate() > 0;

		pstmt.close();
		con.close();
		
		return result;
	}

	public boolean updateUser(User user) throws SQLException {
		boolean result = false;

		Connection con = DriverManager.getConnection(URL);
		PreparedStatement pstmt =
			con.prepareStatement(SQL_UPDATE_USER);

		int k = 1;
		pstmt.setString(k++, user.getLogin());
		pstmt.setString(k++, user.getPassword());
		pstmt.setInt(k++, user.getId());

		result = pstmt.executeUpdate() > 0;

		pstmt.close();
		con.close();
		
		return result;
	}

	// id = 0
	public boolean insertUser(User user) throws SQLException {
		boolean result = false;

		Connection con = DriverManager.getConnection(URL);
		PreparedStatement pstmt =
			con.prepareStatement(SQL_INSERT_USER, Statement.RETURN_GENERATED_KEYS);
		ResultSet rs = null;

		int k = 1;
		pstmt.setString(k++, user.getLogin());
		pstmt.setString(k++, user.getPassword());

		if (pstmt.executeUpdate() > 0) {
			rs = pstmt.getGeneratedKeys();
			if (rs.next()) {
				int id = rs.getInt(1);
				user.setId(id);
			}
			result = true;
		}

		rs.close();
		pstmt.close();
		con.close();
		
		return result;
	}

	public User findUserByLogin(String login) throws SQLException {
		User user = null;
		Connection con = DriverManager.getConnection(URL);

		PreparedStatement pstmt =

				con.prepareStatement(SQL_FIND_USER_BY_LOGIN);
		pstmt.setString(1, login);

		ResultSet rs = pstmt.executeQuery();
		if (rs.next()) {
			user = extractUser(rs);
		}

		rs.close();
		pstmt.close();
		con.close();

		return user;
	}

	// =============== util methods

	private User extractUser(ResultSet rs) throws SQLException {
		User user = new User();
		user.setId(rs.getInt("id"));
		user.setLogin(rs.getString("login"));
		user.setPassword(rs.getString("password"));
		return user;
	}

}
