import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Test {
	
	private static final String URL = 
			"jdbc:mysql://localhost:3306/testdb"
			+ "?user=testuser&password=testpass";

	private static final String SQL_FIND_ALL_USERS = 
			"SELECT * FROM users";

	public static void main(String[] args) throws SQLException {
		// (1)
		Connection con = DriverManager.getConnection(URL);
		System.out.println("con = " + con);
		
		// (2)
		Statement stmt = con.createStatement();
		
		// (3)
		ResultSet rs = stmt.executeQuery(SQL_FIND_ALL_USERS);
		
		// (4)
		while (rs.next()) {
			System.out.println(rs.getString("login"));
		}
		
		rs.close();
		stmt.close();
		con.close(); // tomcat apache
		
	}

}



/*

check port 8080

netstat  -ano | findstr 8080

netstat -anop | grep 8080

*/