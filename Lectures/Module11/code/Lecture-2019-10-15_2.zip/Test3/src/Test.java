import java.sql.SQLException;

import db.DBManager;
import db.entity.User;

public class Test {
	
	public static void main(String[] args) throws SQLException {
		DBManager dbManager = DBManager.getInstance();

		dbManager.findAllUsers().forEach(System.out::println);

		System.out.println("~~~");

	}


}
