package db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import db.entity.User;

public class DBManager {

	// =================== singleton

	private static DBManager instance;

	public static synchronized DBManager getInstance() {
		if (instance == null) {
			instance = new DBManager();
		}
		return instance;
	}

	private DBManager() {
		// ...
	}

	// =================== singleton

	private static final String URL = "jdbc:mysql://localhost:3306/testdb" + "?user=testuser&password=testpass";

	private static final String SQL_FIND_ALL_USERS = "SELECT * FROM users";

	private static final String SQL_FIND_USER_BY_LOGIN = "SELECT * FROM users WHERE login=?"; // StringBuilder

	private static final String SQL_INSERT_USER = "INSERT INTO users VALUES (DEFAULT, ?, ?)";

	private static final String SQL_UPDATE_USER = "UPDATE users SET login=?, password=? WHERE id=?";

	private static final String SQL_DELETE_USER = "DELETE FROM users WHERE id=?";

	public List<User> findAllUsers() {
		List<User> users = new ArrayList<>();

		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			con = DriverManager.getConnection(URL);
			stmt = con.createStatement();
			rs = stmt.executeQuery(SQL_FIND_ALL_USERS);

			while (rs.next()) {
				users.add(extractUser(rs));
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs);
			close(stmt);
			close(con);
		}
		return users;
	}

	public boolean insertUser(User user) {
		boolean result = false;

		Connection con = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		try {
			con = DriverManager.getConnection(URL);
			pstmt = con.prepareStatement(SQL_INSERT_USER, Statement.RETURN_GENERATED_KEYS);

			int k = 1;
			pstmt.setString(k++, user.getLogin());
			pstmt.setString(k++, user.getPassword());

			if (pstmt.executeUpdate() > 0) {
				rs = pstmt.getGeneratedKeys();
				if (rs.next()) {
					int id = rs.getInt(1);
					user.setId(id);
				}
				result = true;
			}
		} catch (SQLException ex) {
			ex.printStackTrace();
		} finally {
			close(rs);
			close(pstmt);
			close(con);
		}

		return result;
	}

	// =============== util methods
	
	private User extractUser(ResultSet rs) throws SQLException {
		User user = new User();
		user.setId(rs.getInt("id"));
		user.setLogin(rs.getString("login"));
		user.setPassword(rs.getString("password"));
		return user;
	}


	private static void close(AutoCloseable ac) {
		if (ac != null) {
			try {
				ac.close();
			} catch (Exception ex) {
				ex.printStackTrace();
			}
		}
	}

}
