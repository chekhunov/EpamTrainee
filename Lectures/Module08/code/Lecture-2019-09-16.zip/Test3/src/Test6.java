public class Test6 {
	
	private static boolean flag;

	synchronized static void m(boolean f) { // Test6.class 
		flag = f;

		try {
			Thread.sleep(333);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println(flag + " == " + f);
	}

	public static void main(String[] args) {
		new Thread() {
			public void run() {
				while (true) {
					Test6.m(false);
				}
			}
		}.start();

		new Thread() {
			public void run() {
				while (true) {
					Test6.m(true);
				}
			}
		}.start();
	}
}
