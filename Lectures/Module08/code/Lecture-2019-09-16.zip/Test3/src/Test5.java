import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Test5 {
	
	private static final Lock MUTEX = new ReentrantLock();

	private boolean flag;

	void m(boolean f) { // this object is a monitor!
		MUTEX.lock(); // <-- in try section
		this.flag = f;

		try {
			Thread.sleep(333);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println(this.flag + " == " + f);
		MUTEX.unlock(); // <-- in finally section
	}

	public static void main(String[] args) {
		Test5 t = new Test5();
		new Thread() {
			public void run() {
				while (true) {
					t.m(false);
				}
			}
		}.start();

		new Thread() {
			public void run() {
				while (true) {
					t.m(true);
				}
			}
		}.start();
	}
}
