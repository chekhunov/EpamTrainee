
public class Test2 {
	
	private boolean flag;
	
	synchronized void m(boolean f) { // this object is a monitor!
		this.flag = f;

		try { Thread.sleep(200); }
		catch (InterruptedException e) { e.printStackTrace(); }
		
		System.out.println(this.flag + " == " + f);
	}
	
	public static void main(String[] args) {
		Test2 t = new Test2();
		
		new Thread() {
			public void run() {
				while (true) {
					t.m(false);
				}
			}
		}.start();

		new Thread() {
			public void run() {
				while (true) {
					t.m(true);
				}
			}
		}.start();
	}
}
