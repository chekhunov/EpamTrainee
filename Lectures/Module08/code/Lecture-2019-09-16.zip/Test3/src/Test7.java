import java.util.Arrays;

public class Test7 {
	
	public static void main(String[] args) throws InterruptedException {
		Thread[] threads = new Thread[5];
		
//		for (Thread t : threads) { // <-- Error!!!
//			t = new Child("Child");
//		}
		
		for (int j = 0; j < threads.length; j++) {
			threads[j] = new Child("Child" + j);
		}
		
		System.out.println(Arrays.toString(threads));
		
		for (Thread t : threads) {
			t.start();
		}

		for (Thread t : threads) {
			t.join();
		}

		System.out.println("Main");
		
	}

}

class Child extends Thread {

	private String message;

	public Child(String message) {
		this.message = message;
	}
	
	@Override
	public void run() {
		for (int j = 0; j < 5; j++) {
			System.out.println(message);
			try {
				sleep(333);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}

