public class Test8 {
	
	public static void main(String[] args) throws InterruptedException {
		// Test8.class == new Test8().getClass()
		
		System.out.println("before");
		Test8.class.notify();
		System.out.println("after");
		
		// dead lock

	}

}
