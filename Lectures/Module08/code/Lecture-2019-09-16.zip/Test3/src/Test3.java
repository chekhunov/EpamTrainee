
public class Test3 {
	
	private boolean flag;
	
	synchronized void m(boolean f) { // this object is a monitor!
		this.flag = f;

		try { Thread.sleep(200); }
		catch (InterruptedException e) { e.printStackTrace(); }
		
		System.out.println(this.flag + " == " + f);
	}
	
	public static void main(String[] args) {
		
		new Thread() {
			public void run() {
				while (true) {
					new Test3().m(false);
				}
			}
		}.start();

		new Thread() {
			public void run() {
				while (true) {
					new Test3().m(true);
				}
			}
		}.start();
	}
}
