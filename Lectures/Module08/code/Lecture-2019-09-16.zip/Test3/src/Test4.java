
public class Test4 {

	private boolean flag;

	void m(boolean f) { // this object is a monitor!
		synchronized (this) { // A 
			this.flag = f;

			try {
				Thread.sleep(200);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}

			System.out.println(this.flag + " == " + f);
		}
	}

	public static void main(String[] args) {
		Test4 t = new Test4();
		new Thread() {
			public void run() {
				while (true) {
					t.m(false);
				}
			}
		}.start();

		new Thread() {
			public void run() {
				while (true) {
					t.m(true);
				}
			}
		}.start();
	}
}
