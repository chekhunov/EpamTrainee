
public class Test8 {

	public static void main(String[] args) {
		new Thread() {
			public void run() {
				while (true) {
					System.out.println("Child");
					try {
						sleep(333);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}.start();

		new Thread() {
			public void run() {
				while (true) {
					System.out.println("Child2");
					try {
						sleep(1333);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		}.start();
	}

}
