
public class Test5 {
	public static void main(String[] args) throws InterruptedException {
		Thread t = new Child();
		System.out.println(t.getState());

		t.start();
		
		while (true) {
			System.out.println(t.getState());
			Thread.sleep(555);
		}
	}

	static class Child extends Thread {
		public void run() {
			while (true) {
				System.out.println("Child");
				try { sleep(333); }
				catch (InterruptedException e) { e.printStackTrace(); }
			}
		}
	}

}
