
public class Test3 {
	
	public static void main(String[] args) {
		Thread t = new MyThread();
		t.setName("Child");
		System.out.println(t.getName());
		
//		t.run(); // <-- wrong way!!!
		t.start();
	}

}


class MyThread extends Thread {
	@Override
	public void run() {
		for (int j = 0; j < 5; j++) {
			System.out.println("======");
			System.out.println(Thread.currentThread().getName());
			System.out.println(this.getName());

			try {
				Thread.sleep(333);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}


