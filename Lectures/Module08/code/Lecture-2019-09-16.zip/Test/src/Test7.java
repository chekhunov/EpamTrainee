
public class Test7 extends Thread {
	
	@Override
	public void run() {
		while (true) {
			System.out.println("Child");
			try {
				sleep(333);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

	public static void main(String[] args) throws InterruptedException {
		new Test7().start();
	}


}
