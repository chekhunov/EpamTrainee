
public class Test9 {

	public static void main(String[] args) throws InterruptedException {
		Thread t = new Thread() {
			public void run() {
				while (true) {
					System.out.println("Child");
					try {
						sleep(333);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};
		
		t.setDaemon(true);
		System.out.println(t.isDaemon());
		
		/////////////////
		
		t.start();
		
		
		Thread.sleep(3333);
		System.out.println("Main finished!");
	}

}
