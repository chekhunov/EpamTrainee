
public class Test {
	
	public static void main(String[] args) throws InterruptedException {
		System.out.println("A");
		
		Thread.sleep(3333);
		System.out.println("B");
		
	}

}
