
public class Test2 {
	
	public static void main(String[] args) throws InterruptedException {
		Thread t = Thread.currentThread();
		
		System.out.println(t);
	
		System.out.println("before");
		t.join(); // 
		System.out.println("after");
		
		
		
		
		
	}

}
