
public class Test {
	
	public static void main(String[] args) {
		new MyThread("AAAAA", 333).start();
		new MyThread("@@", 1333).start();
		new MyThread("#########", 2333).start();
	}

}

class MyThread extends Thread {
	
	private String message;

	private int time;

	public MyThread(String message, int time) {
		this.message = message;
		this.time = time;
	}
	
	@Override
	public void run() {
		while (true) {
			System.out.println(message);
			try {
				sleep(time);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
}


