
public class Test3 {
	
	public static void main(String[] args) throws InterruptedException {
		Thread t = Thread.currentThread();
		t.interrupt(); // interrupted status --> true
		
//		Thread.sleep(333); // <-- exception!!!
//		t.join();
		
		synchronized ("asdf") {
			"asdf".wait(); // <-- main invoke this method
		}
		

	}

}
