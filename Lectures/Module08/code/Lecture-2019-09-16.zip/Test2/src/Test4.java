
public class Test4 {
	
	public static void main(String[] args) throws InterruptedException {
		Thread child = new Child();
		child.start();
		
		Thread.sleep(3333);
		
//		child.stop();
		System.out.println("Try to stop a child");
		child.interrupt();
	}
	
	static class Child extends Thread {
		public void run() {
			while (true) {
				System.out.println("Child");
				try {
					sleep(333);
				} catch (InterruptedException e) {
//					return;
					break;
				}
			}
			System.out.println("Child is finished");
		}
	}

}
