
public class Test2 {
	
	public static void main(String[] args) {
		Thread t = Thread.currentThread();
		
		System.out.println(t.isInterrupted());
		System.out.println(t.isInterrupted());
		System.out.println("~~~");
		
		t.interrupt();

		System.out.println(t.isInterrupted());
		System.out.println(t.isInterrupted());
		System.out.println("~~~");
		
		System.out.println(Thread.interrupted());
		System.out.println(t.isInterrupted());
		System.out.println(Thread.interrupted());
	}

}
