
public class Test6 extends Thread {

	public static void main(String[] args) throws InterruptedException {
		Test6 t = new Test6();
		t.start();
		
		new Test6().start();
		
		Thread.sleep(3333);
		System.out.println("Main is stopped!");
	}

	public void run() {
		while (true) {
			System.out.println(getName());
			try {
				Thread.sleep(333);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}

}
