import java.util.Scanner;

public class Test10 {

	private static class Worker extends Thread {

		private String message;

		private int time;

		public Worker(String message, int time) {
			this.message = message;
			this.time = time;
		}

		public void run() {
			while (true) {
				System.out.println(message);
				try {
					sleep(time);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public static void main(String[] args) throws InterruptedException {
		Thread[] workers = { new Worker("aaaaa", 333), new Worker("@@@@@@@", 777), new Worker("TTTTTTTTTTTT", 555) };
		for (Thread t : workers) {
			t.start();
		}

		new Thread() {
			public void run() {
				Scanner s = new Scanner(System.in);
				while (s.hasNextLine()) {
					String line = s.nextLine();
					if ("stop".equals(line)) {
						break;
					}
				}

				for (Thread t : workers) {
					t.stop();
				}
			}

		}.start();

		System.out.println("ok");
	}

}
