
public class Test7 {

	public static void main(String[] args) throws InterruptedException {
		Thread t = new Thread() {
			public void run() {
				while (true) {
					System.out.println("child");
					try {
						Thread.sleep(333);
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			}
		};
		t.setDaemon(true);
		t.start();
		
		Thread.sleep(3333);
		System.out.println("OK");
	}

}
