
public class Test8 {
	
	private static class Worker extends Thread {

		private String message;

		private int time;

		public Worker(String message, int time) {
			this.message = message;
			this.time = time;
		}
		
		public void run() {
			while (true) {
				System.out.println(message);
				try {
					sleep(time);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

	}
	
	public static void main(String[] args) {
		new Worker("aaaaa", 333).start();
		new Worker("@@@@@@@", 2333).start();
		new Worker("TTTTTTTTTTTT", 1333).start();
	}

}
