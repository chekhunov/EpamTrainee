
public class Test3 {

	public static void main(String[] args) {
		Thread t = new Child();
		
		System.out.println(t.getState());
		System.out.println(t);
		
//		t.run(); // <-- main thread
		t.start();
		
		System.out.println("Main is finished");
	}
	
}

class Child extends Thread {

	public void run() {
		while (true) {
			System.out.println("child");
			try {
				sleep(333);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
	
	
}
