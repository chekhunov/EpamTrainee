
public class Test9 {

	private static class Worker extends Thread {

		private String message;

		private int time;

		public Worker(String message, int time) {
			this.message = message;
			this.time = time;
		}

		public void run() {
			for (int j = 0; j < 5; j++) {
				System.out.println(message);
				try {
					sleep(time);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

	}

	public static void main(String[] args) throws InterruptedException {
		Thread[] workers = { new Worker("aaaaa", 333),
				new Worker("@@@@@@@", 777),
				new Worker("TTTTTTTTTTTT", 555) };
		for (Thread t : workers) {
			t.start();
		}

		for (Thread t : workers) {
			t.join();
		}
		
		System.out.println("ok");
	}

}
