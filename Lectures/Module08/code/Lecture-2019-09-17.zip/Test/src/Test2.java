
public class Test2 {
	
	public static void main(String[] args) throws InterruptedException {
		Thread t = Thread.currentThread(); // <-- thread
		t.setName("aaaaaaaaa");
		System.out.println(t);

		t.setName("AAAAAAAAA");
		System.out.println(t);
		
		t.join(); // <-- t (T)    A waits for T termination
		
		System.out.println("ok");
	}

}
