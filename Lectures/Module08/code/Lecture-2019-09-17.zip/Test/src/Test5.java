
public class Test5 {

	public static void main(String[] args) throws InterruptedException {
		Thread t = new Thread(new Child());
		t.setDaemon(true);
		t.start();
		
		System.out.println(t.isDaemon());

		Thread.sleep(2000);
		System.out.println("Main is finished");
	}

	static class Child implements Runnable {

		public void run() {
			while (true) {
				System.out.println("child");
				try {
					Thread.sleep(333);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

	}
}
