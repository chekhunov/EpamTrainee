
public class Test4 {

	public static void main(String[] args) throws InterruptedException {
		Thread t = new Child();
		t.start();
		t.setDaemon(true);
		
		System.out.println(t.isDaemon());

		Thread.sleep(2000);
		System.out.println("Main is finished");
	}

	static class Child extends Thread {

		public void run() {
			while (true) {
				System.out.println("child");
				try {
					sleep(333);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}

	}
}
