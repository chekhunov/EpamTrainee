
public class Test {
	
	public static void main(String[] args) throws InterruptedException {
		System.out.println("before");
		Thread.sleep(3333);
		System.out.println("after");
	}

}
