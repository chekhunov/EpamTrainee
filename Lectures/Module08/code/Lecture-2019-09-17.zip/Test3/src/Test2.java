
public class Test2 {
	
	private static final Object MONITOR = new Object();
	
	private boolean flag;
	
	void m(boolean f) {
		synchronized (MONITOR) {
			flag = f;
			
			try { Thread.sleep(333); }
			catch (InterruptedException e) { e.printStackTrace(); }
			
			System.out.println(flag + " == " + f);
		}
	}
	
	public static void main(String[] args) {
		Test2 t = new Test2();
		
		new Thread() {
			public void run() {
				while (true) {
					t.m(true);
				}
			}
		}.start();

		new Thread() {
			public void run() {
				while (true) {
					t.m(false);
				}
			}
		}.start();
	}

}
