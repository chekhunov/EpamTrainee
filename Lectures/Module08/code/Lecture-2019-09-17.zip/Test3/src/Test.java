
public class Test {
	
	private boolean flag;
	
	void m(boolean f) {
		flag = f;
		
		try { Thread.sleep(333); }
		catch (InterruptedException e) { e.printStackTrace(); }
		
		System.out.println(flag + " == " + f);
	}
	
	public static void main(String[] args) {
		Test t = new Test();
		
		new Thread() {
			public void run() {
				while (true) {
					t.m(true);
				}
			}
		}.start();

		new Thread() {
			public void run() {
				while (true) {
					t.m(false);
				}
			}
		}.start();
	}

}
