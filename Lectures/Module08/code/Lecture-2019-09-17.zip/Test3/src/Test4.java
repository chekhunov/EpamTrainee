
public class Test4 {

	private static boolean flag;

	static synchronized void m(boolean f) { // Test4.class
		flag = f;

		try {
			Thread.sleep(333);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println(flag + " == " + f);
	}

	public static void main(String[] args) {

		new Thread() {
			public void run() {
				while (true) {
					Test4.m(true);
				}
			}
		}.start();

		new Thread() {
			public void run() {
				while (true) {
					Test4.m(false);
				}
			}
		}.start();
	}

}
