
public class Test6 {

	public static void main(String[] args) throws InterruptedException {
		Object o = new Object();
		
		System.out.println("before");
		synchronized (o) {
			o.wait(); // <-- main 
		}
		System.out.println("after");
	}

}
