
public class Test7 {
	
	static long x;
	
	public static final int N = 100_000;

	public static void test() throws InterruptedException {
		
		Thread t = new Thread() {
			public void run() {
				for (int j = 0; j < N; j++) {
					x++;
				}
			}
		};

		Thread t2 = new Thread() {
			public void run() {
				for (int j = 0; j < N; j++) {
					x--;
				}
			}
		};

		t.start();
		t2.start();
		
		t.join();
		t2.join();
		
		System.out.println(x);
		x = 0;

	}
	
	public static void main(String[] args) throws InterruptedException {
		while (true) {
			test();
		}
	}

}
