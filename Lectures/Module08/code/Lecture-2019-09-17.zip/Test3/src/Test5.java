import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Test5 {
	
	private static final Lock MUTEX = new ReentrantLock();

	private static boolean flag;

	static void m(boolean f) { // Test4.class
		MUTEX.lock(); // try
		flag = f;

		try {
			Thread.sleep(333);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

		System.out.println(flag + " == " + f);
		MUTEX.unlock(); // finally
	}

	public static void main(String[] args) {

		new Thread() {
			public void run() {
				while (true) {
					Test5.m(true);
				}
			}
		}.start();

		new Thread() {
			public void run() {
				while (true) {
					Test5.m(false);
				}
			}
		}.start();
	}

}
