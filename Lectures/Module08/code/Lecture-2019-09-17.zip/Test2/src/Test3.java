
public class Test3 {

	public static void main(String[] args) throws InterruptedException {
		Thread t = new Thread() {
			public void run() {
				while (true) {
					System.out.println("Child");

					try {
						sleep(333);
					} catch (InterruptedException e) {
//						return;
						break;
					}
				}
				System.out.println("Child is stopped");
			}
		};
		
		t.start();
		
		Thread.sleep(3333);
		
		t.interrupt();
		
		t.join();
		System.out.println("Main is stopped");

	}

}
