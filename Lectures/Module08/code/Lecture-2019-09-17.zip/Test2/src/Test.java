
public class Test {
	
	public static void main(String[] args) throws InterruptedException {
		Thread t = Thread.currentThread(); // t? <-- main thread
		
		System.out.println(t.isInterrupted()); // false
		System.out.println(t.isInterrupted());
		
		t.interrupt(); // flag to true

		System.out.println(t.isInterrupted()); // true
		System.out.println(t.isInterrupted()); // true
		System.out.println("~~~");
		
		System.out.println(Thread.interrupted()); // true
		System.out.println(Thread.interrupted()); // false
		
	}

}
