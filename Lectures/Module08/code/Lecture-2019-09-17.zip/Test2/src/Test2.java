
public class Test2 {
	
	public static void main(String[] args) throws InterruptedException {
		Thread t = Thread.currentThread();  // main thread
		t.interrupt(); 

//		Thread.sleep(333); // <--
//		t.join();
		
		synchronized ("asdf") {
			"asdf".wait(); // <-- main thread invoke this method
		}
	}

}
