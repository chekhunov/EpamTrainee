
public class Test4 {

	public static void main(String[] args) throws InterruptedException {
		Thread t = new Thread() {
			public void run() {
				while (!isInterrupted()) {
					System.out.println("Child");
					try {
						sleep(333);
					} catch (InterruptedException e) {
						interrupt();
					}
				}
				System.out.println("Child is stopped");
			}
		};
		
		t.start();
		
		Thread.sleep(2555);
		
		t.interrupt();
		
		t.join();
		System.out.println("Main is stopped");

	}

}
