
public class Test4 {
	
	private static final String STR = "asdfasdfasdf";
	
	private static final int N = 1_000_000;
	
	static void testString() {
		String s = "";
		long before = System.currentTimeMillis();
		for (int j = 0; j < N; j++) {
			s = s + STR;
		}
		long after = System.currentTimeMillis();
		System.out.println(after - before);
	}

	static void testString2() {
		String s = "";
		long before = System.currentTimeMillis();
		for (int j = 0; j < N; j++) {
			s = s.concat(STR);
		}
		long after = System.currentTimeMillis();
		System.out.println(after - before);
	}

	static void testStringBuilder() {
		StringBuilder sb = new StringBuilder();
		long before = System.currentTimeMillis();
		for (int j = 0; j < N; j++) {
			sb.append(STR);
		}
		long after = System.currentTimeMillis();
		System.out.println(after - before);
	}

	static void testStringBuffer() {
		StringBuffer sb = new StringBuffer();
		long before = System.currentTimeMillis();
		for (int j = 0; j < N; j++) {
			sb.append(STR);
		}
		long after = System.currentTimeMillis();
		System.out.println(after - before);
	}
	
	public static void main(String[] args) {
		testStringBuilder();
		testStringBuffer();

		//testString2();
		//testString();

	}

}
