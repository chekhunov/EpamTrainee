
public class Test5 {
	
	public static void main(String[] args) {
		
//		"as".toString();
		
		String s;
		s = new String(new char[] {'e', 'n'});
		s = new String(new char[] {'u', 'k'});
		s = new String(new char[] {'r', 'u'});
		s = new String(new char[] {'u', 'a'});
		s = new String(new char[] {'j', 'a'});
		s = new String(new char[] {'f', 'r'});
		s = new String(new char[] {'e', 's'});
		
		System.out.println(s == s.intern());
	}

}
