
public class Test2 {
	
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder()
				.append("asdf")
				.append(78)
				.append(new Test2());
		System.out.println(sb);
	}

}
