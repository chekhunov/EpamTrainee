import java.util.Locale;
import java.util.Scanner;

public class Test7 {
	
	public static void main(String[] args) {
		System.out.println(Locale.getDefault());
		
		Locale.setDefault(Locale.ENGLISH);
		
		
		Scanner s = new Scanner("12.13 234.34");
		
		System.out.println(s.nextDouble());
		
			
	}

}
