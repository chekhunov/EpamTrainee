
public class Test {
	
	public static void main(String[] args) {
		String s = "as";
		String s2 = "df";
		
		System.out.println("asdf" == "as" + "df");
		
		final String s3 = "as";
		final String s4 = "df";
		System.out.println("asdf" == s3 + s4);

		String s5 = "as";
		final String s6 = "df";
		System.out.println("asdf" == s5 + s6);

		System.out.println("asdf" == s + s2);
		
		System.out.println("asdf7" == "asdf" + 7);

//		int x = 7;
		final int x = 7;
		System.out.println("asdf7" == "asdf" + x);
	}

}
