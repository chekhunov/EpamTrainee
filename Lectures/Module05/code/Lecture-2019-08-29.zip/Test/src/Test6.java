import java.util.Locale;

public class Test6 {
	
	public static void main(String[] args) {
		Locale locale = new Locale("LANguage", "COUntry", "VAriant");
		System.out.println(locale);
	}

}
