
public class Test3 {
	
	public static void main(String[] args) {
		// try to uncomment the following line!
		"asdf".toString();
		
		// pool: ["asdf"]
		String s = new String(new char[] {'a', 's', 'd', 'f'});
		System.out.println(s == s.intern()); // s == "asdf"
		// pool: ['asdf']

		System.out.println("asdf" == s); // true
		System.out.println("asdf" == s.intern()); // true
		
		

				
	}

}
