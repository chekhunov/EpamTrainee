
public class Test {
	
	public static void main(String[] args) {
		// []
		String s;

//		s = "asdf";
//		["asdf"]

		s = new String(new char[] {'a', 's', 'd', 'f'});
		// []
	
		s.intern();
		// ['asdf']

		String s2 = new String(new char[] {'a', 's', 'd', 'f'});
		System.out.println(s2 == s2.intern());
		System.out.println(s == s2.intern());

		
		
		
	}

}
