import java.util.Locale;
import java.util.Scanner;

public class Test7 {
	
	public static void main(String[] args) {
//		Locale locale = new Locale("LANguage", "COUNtry", "VARiant");
//		System.out.println(locale);

		Locale.setDefault(Locale.ENGLISH);
		System.out.println(Locale.getDefault());
		
//		Scanner s = new Scanner("13,43");
		Scanner s = new Scanner("13.43");
		System.out.println(s.hasNextDouble());
		System.out.println(s.nextDouble());
		
	}

}
