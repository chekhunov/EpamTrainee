
public class Test4 {
	
	public static void main(String[] args) {
		final String s1 = "as";
		final String s2 = "df";
		
		System.out.println("asdf" == s1 + s2);
		
		final int x = 7;
		System.out.println("asdf7" == "asdf" + x);
	
		final boolean f = true;
		System.out.println("trueASDF" == f + "ASDF");
		
		
		
	}

}
