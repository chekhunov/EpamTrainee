
public class Test3 {
	
	public static void main(String[] args) {
		
		String s2 = new String(new char[] {'a', 's', 'd', 'f'});

		// try to uncomment the following line!!!
//		s2.intern();
		String s = "asdf";


		
		System.out.println(s2 == s);
		
		
		
		
		

	}

}
