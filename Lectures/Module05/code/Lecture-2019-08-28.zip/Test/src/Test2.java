
public class Test2 {
	
	public static void main(String[] args) {
		
		// []
		String s = "asdf";
		// ["asdf"]
		
		String s2 = new String("asdf"); // 'asdf'
		
		System.out.println(s == s.intern()); // true
		System.out.println(s2 == s2.intern()); // false
		System.out.println(s == s2.intern()); // false

	}

}
