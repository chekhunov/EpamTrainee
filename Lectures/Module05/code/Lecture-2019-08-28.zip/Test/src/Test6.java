
public class Test6 {
	
	public static void main(String[] args) {
		String s;
		
		s = new String(new char[] {'e', 'n'});
		s = new String(new char[] {'r', 'u'});
		s = new String(new char[] {'f', 'r'});

		System.out.println(s == s.intern());
	}

}
