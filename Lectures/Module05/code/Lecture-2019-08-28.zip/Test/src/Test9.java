import java.io.File;
import java.io.IOException;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test9 {
	
	static String getInput(String fileName) throws IOException {
		Scanner s = new Scanner(new File(fileName));
		StringBuilder sb = new StringBuilder();
		while (s.hasNextLine()) {
			sb.append(s.nextLine()).append(System.lineSeparator());
		}
		
		return sb.toString();
	}
	
	private static final String REGEX =
			"(?m)^(\\S*)(\\s*)(\\S*)(.*)$";
	
	public static void main(String[] args) throws IOException {
		String input = getInput("input.txt");
		
		System.out.println(input);
		
		System.out.println("~~~");
		
		Pattern p = Pattern.compile(REGEX);
		Matcher m = p.matcher(input);
		
		while (m.find()) {
			System.out.println(new StringBuilder()
					.append(m.group(3))
					.append(m.group(2))
					.append(m.group(1))
					.append(m.group(4)));
		}
		
	}

}
