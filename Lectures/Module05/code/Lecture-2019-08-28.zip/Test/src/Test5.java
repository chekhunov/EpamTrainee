
public class Test5 {
	
	private static final String STR = "asdfasdfadf"; 

	private static final int N = 20_000_000; 

	static void testString() {
		String s = "";
		long before = System.currentTimeMillis();
		for (int j = 0; j < N; j++) {
			s = s + STR;
		}
		long after = System.currentTimeMillis();
		System.out.println(after - before);
	}

	static void testString2() {
		String s = "";
		long before = System.currentTimeMillis();
		for (int j = 0; j < N; j++) {
			s = s.concat(STR);
		}
		long after = System.currentTimeMillis();
		System.out.println(after - before);
	}

	static void testStringBuffer() {
		StringBuffer s = new StringBuffer();
		long before = System.currentTimeMillis();
		for (int j = 0; j < N; j++) {
			s = s.append(STR);
		}
		long after = System.currentTimeMillis();
		System.out.println(after - before);
	}

	static void testStringBuilder() {
		StringBuilder s = new StringBuilder();
		long before = System.currentTimeMillis();
		for (int j = 0; j < N; j++) {
			s = s.append(STR);
		}
		long after = System.currentTimeMillis();
		System.out.println(after - before);
	}
	
	
	
	public static void main(String[] args) {
		testStringBuilder();
		testStringBuffer();
		testString2();
		testString();
	}

}
