import java.util.Locale;
import java.util.ResourceBundle;

public class Test8 {
	
	public static void main(String[] args) {
		Locale locale = new Locale("ru", "UA", "Kharkov");
		
		ResourceBundle rb = 
				ResourceBundle.getBundle("messages", locale);
		
		System.out.println(rb.getString("hanger"));
	}

}
