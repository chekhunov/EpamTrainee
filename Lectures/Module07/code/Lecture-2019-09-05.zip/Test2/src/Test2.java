import java.io.File;
import java.io.IOException;

public class Test2 {
	
	public static void main(String[] args) throws IOException {
		File file = new File("a/b/./../z");
		
		System.out.println(file.getAbsolutePath());
		System.out.println(file.getCanonicalPath());
	}

}
