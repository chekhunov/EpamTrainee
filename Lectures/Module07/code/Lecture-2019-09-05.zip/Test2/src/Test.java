import java.io.File;

public class Test {
	
	public static void main(String[] args) {
		File file = new File("a/b/c");
		
		// (1)
		System.out.println(file.getParent());
		
		// (2)
		System.out.println(file.exists());
		
		file = new File(".test.txt");
		System.out.println(file.exists());
		System.out.println(file.isHidden());
		
		
	}

}
