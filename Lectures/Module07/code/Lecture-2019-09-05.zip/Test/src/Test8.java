import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;

public class Test8 {

	public static void main(String[] args) throws IOException {
		PrintWriter out = new PrintWriter(
			new OutputStreamWriter(
				new FileOutputStream("out.txt", true), 
					"Cp866"));

		out.println("asdf;lkjasdf");
		out.println("��������");
		out.close();

	}

}
