import java.io.IOException;
import java.io.PrintWriter;

public class Test6 {
	
	public static void main(String[] args) throws IOException {
		PrintWriter out = new PrintWriter("out.txt");
		out.println("asdf;lkjasdf");
		out.println("��������");
		out.close();
		
//		out.flush();
		
	//	System.out.println(System.getProperty("user.dir"));
	}

}
