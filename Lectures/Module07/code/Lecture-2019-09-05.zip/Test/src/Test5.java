import java.io.IOException;
import java.util.Scanner;

public class Test5 {
	
	public static void main(String[] args) throws IOException {
//		Console console = System.console();
//		System.out.println(console);
		
		Scanner s = new Scanner(System.in);
		while (s.hasNextLine()) {
			String line = s.nextLine();
			System.out.println(line);
			if ("stop".equals(line)) {
				break;
			}
		}
		s.close();
		//System.in.read();
	}

}
