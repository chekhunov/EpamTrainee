import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Test9 {

	public static void main(String[] args) throws IOException {
		BufferedReader in = new BufferedReader(
				new FileReader("out.txt"));
		
		String line;
		while ((line = in.readLine()) != null) {
			System.out.println(line);
		}
		
		in.close();

	}

}
