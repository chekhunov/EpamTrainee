import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Test7 {
	
	public static void main(String[] args) throws IOException {
		PrintWriter out = new PrintWriter(
			new FileWriter("out.txt", true));

		
		out.println("asdf;lkjasdf");
		out.println("��������");
		out.close();
		
	}

}
