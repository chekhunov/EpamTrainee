import java.io.FileNotFoundException;
import java.io.PrintStream;

public class Test {
	
	public static void main(String[] args) throws FileNotFoundException {
		System.setOut(new PrintStream("out.txt"));
		
		System.out.println("asdfasdf");
		System.out.println(System.out);
	}

}
