import java.io.IOException;
import java.util.Arrays;

public class Test4 {
	
	public static void main(String[] args) throws IOException {
		byte[] buf = new byte[4];
		while (true) {
			int n = System.in.read(buf);
//			System.out.println(Arrays.toString(buf));
			String line = new String(buf, 0, n);
			System.out.println(line);
			if ("stop".equals(line)) {
				break;
			}
		}
	}

}
