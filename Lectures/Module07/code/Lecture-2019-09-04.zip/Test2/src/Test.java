import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

public class Test {
	
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		A a = new A();
		ObjectOutputStream oos = new ObjectOutputStream(
				new FileOutputStream("a.obj"));
		oos.writeObject(a);
		oos.close();
		
		ObjectInputStream ois = new ObjectInputStream(
				new FileInputStream("a.obj"));
		Object o = ois.readObject();
		System.out.println(o);
	}

}

class A implements Serializable {
	
	transient int x = 7;
	
	int y;

	A() {
		System.out.println("A#constr");
	}

	@Override
	public String toString() {
		return "A [x=" + x + "]";
	}

}
