import java.io.IOException;
import java.util.Scanner;

public class Test4 {
	
	public static void main(String[] args) throws IOException {
		Scanner s = new Scanner(System.in);
		while (s.hasNextLine()) {
			System.out.println("~~~");
			String line = s.nextLine();
			System.out.println(line);
		}
	}

}
