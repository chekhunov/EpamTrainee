import java.io.IOException;

public class Test2 {
	
	public static void main(String[] args) throws IOException {
		byte[] buf = new byte[4];
		while (true) {
			int n = System.in.read(buf);
//			System.out.println(Arrays.toString(buf));
			String line = new String(buf, 0, n);
			System.out.println(line);
			System.out.println("~~~");
		}
		
	}

}
