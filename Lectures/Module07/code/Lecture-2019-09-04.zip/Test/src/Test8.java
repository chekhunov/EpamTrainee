import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Test8 {
	
	public static void main(String[] args) {
		PrintWriter out = null;
		try {
			out = new PrintWriter(
				new FileWriter("out.txt", true));
			out.println("asdfasdfS");
			out.println("����");
		} catch (IOException ex) {
			ex.printStackTrace();
		} finally {
			if (out != null) {
				out.close();
			}
		}

	}

	public static void main3(String[] args) {
		try (PrintWriter out = new PrintWriter(
				new FileWriter("out.txt", true))) {
			out.println("asdfasdfS");
			out.println("����");
		} catch (IOException ex) {
			ex.printStackTrace();
		}

	}

	public static void main2(String[] args) throws IOException {
		PrintWriter out = new PrintWriter(
				new FileWriter("out.txt", true));

		out.println("asdfasdfS");
		out.println("����");

		out.close();
	}

}
