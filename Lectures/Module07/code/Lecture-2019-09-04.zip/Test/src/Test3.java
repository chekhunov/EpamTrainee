import java.io.IOException;

public class Test3 {
	
	public static void main(String[] args) throws IOException {
		System.out.println("a");
		System.out.close();
		System.out.println("b");
		
		System.in.read();
		System.in.close();
		System.in.read();
	}

}
