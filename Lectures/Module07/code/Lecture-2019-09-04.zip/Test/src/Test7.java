import java.io.IOException;
import java.io.PrintWriter;

public class Test7 {
	
	public static void main(String[] args) throws IOException {
		//System.setOut(new PrintStream("out.txt"));
		//System.out.println("asdfasdfadsf");
		
//		PrintWriter out = new PrintWriter("out.txt", "UTF-16LE");
		PrintWriter out = new PrintWriter("out.txt");
		out.println("asdfasdfS");
		out.println("����");
		out.close();
		
	}

}
