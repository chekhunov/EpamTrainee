import java.io.File;
import java.io.FileFilter;
import java.io.IOException;

public class Test10 {
	
	public static void main(String[] args) throws IOException {
		File root = new File(".");
		File[] files = root.listFiles();
		for (File file : files) {
			System.out.println(file.getName());
		}
		System.out.println("~~~");
		
		files = root.listFiles(new FileFilter() {
			public boolean accept(File file) {
				return file.isDirectory();
			}
		});
		
		for (File file : files) {
			System.out.println(file);
		}

		System.out.println("~~~");
		
		files = root.listFiles((file) -> file.isFile());
		
		for (File file : files) {
			System.out.println(file);
		}

	}

}
