package com.my;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/MyServlet2")
public class MyServlet2 extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("MyServlet2#doGet");
	
		// (1)
		request.setAttribute("name", "ivanov");

		// (2)
		HttpSession session = request.getSession();
		session.setAttribute("name", "ivanov");

		// (3)
		ServletContext sc = getServletContext();
		sc.setAttribute("name", "ivanov");
		
		
	}


}
