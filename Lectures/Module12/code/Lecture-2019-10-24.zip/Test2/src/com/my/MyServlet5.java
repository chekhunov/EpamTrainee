package com.my;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MyServlet5")
public class MyServlet5 extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("MyServlet5#doGet");
		
//		response.sendRedirect("http://google.com");
		
		// post
		response.sendRedirect("MyServlet6?x=7&y=5");
		
		// get
		request.getRequestDispatcher("MyServlet6")
			.forward(request, response);
		

	}


}
