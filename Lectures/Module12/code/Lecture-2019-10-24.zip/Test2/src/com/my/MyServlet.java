package com.my;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/MyServlet")
public class MyServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("MyServlet#doGet");

		response.getWriter().println("A");
		
		RequestDispatcher rd =
//				request.getRequestDispatcher("MyServlet2");
				request.getRequestDispatcher("test.txt");
//		rd.forward(request, response);
		rd.include(request, response);

		response.getWriter().println("B");
		
		System.out.println("finish");
	}


}
