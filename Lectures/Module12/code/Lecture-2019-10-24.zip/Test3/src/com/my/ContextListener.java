package com.my;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class ContextListener implements ServletContextListener {

    public void contextInitialized(ServletContextEvent sce)  { 
    	System.out.println("Context init"); // <--
    	
    	ServletContext context = sce.getServletContext();
    	String encoding = context.getInitParameter("encoding");
    	System.out.println("encoding ==> " + encoding);
    }
}
