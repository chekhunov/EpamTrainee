package com.my;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class ContextListener implements ServletContextListener {
    public void contextDestroyed(ServletContextEvent sce)  { 
    	
    }

    public void contextInitialized(ServletContextEvent sce)  { 
    	System.out.println("ContextListener");
    	
    	String encoding = 
			sce.getServletContext().getInitParameter("encoding");
    	System.out.println("encoding ==> " + encoding);
    }
	
}
