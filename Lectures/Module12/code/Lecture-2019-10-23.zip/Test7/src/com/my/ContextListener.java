package com.my;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class ContextListener implements ServletContextListener {

    public void contextInitialized(ServletContextEvent sce)  { 
    	ServletContext sc = sce.getServletContext();
    	String encoding = sc.getInitParameter("encoding");
    	System.out.println("encoding ==> " + encoding);

    }

    public void contextDestroyed(ServletContextEvent sce)  { 

    }
	
}
