package com.my;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/MyServlet2")
public class MyServlet2 extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// you can save attributes in the following containers:
		
		// (1) request
		request.setAttribute("message", "request");

		// (2) session
		HttpSession session = request.getSession();
		session.setAttribute("message", "session");

		// (3) servlet context
		ServletContext context = getServletContext();
		context.setAttribute("message", "context");
	}

}
