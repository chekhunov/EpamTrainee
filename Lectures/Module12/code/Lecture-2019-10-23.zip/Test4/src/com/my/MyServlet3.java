package com.my;

import java.io.IOException;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/MyServlet3")
public class MyServlet3 extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("MyServlet3#doGet");
		
		HttpSession session = request.getSession();
		System.out.println(session.isNew());
		System.out.println(session.getId());
		
		String login = request.getParameter("login");
		System.out.println("login = " + login);
		
		String address = "index.jsp";
		
		address = response.encodeURL(address);
		
		response.getWriter().printf("<html><body>"
			+ "<a href='%s'>Index</a>"
			+ "</body></html>", address);
		
		
		
		

	}

}
