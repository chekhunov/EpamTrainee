package com.my;

import java.io.IOException	;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/a/b/c/d")
public class MyServlet3 extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("MyServlet3#doGet");
	
	//	response.sendRedirect("MyServlet4");
		
		String path = getServletContext().getContextPath();
		System.out.println("path ==> " + path);
		response.sendRedirect(path + "/MyServlet4");
//		response.sendRedirect("http://google.com");
	}

}
