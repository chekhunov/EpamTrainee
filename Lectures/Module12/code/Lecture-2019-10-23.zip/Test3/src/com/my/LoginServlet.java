package com.my;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("LoginServlet#doGet");
	
		// (1) obtain an input info
		String login = req.getParameter("login");
		System.out.println("login ==> " + login);

		// (2) generate a result
		String message = "Hi, " + login + "!";
		
		// (3) save a result as an attribute in container
		req.setAttribute("result", message);
		
		// (4) go to view layer
		req.getRequestDispatcher("result.jsp")
			.forward(req, resp);

	}
}
