package com.my;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebServlet;
import javax.xml.ws.RespectBinding;

@WebServlet("/MyServlet5")
public class MyServlet5 implements Servlet {

	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init");
		System.out.println(Thread.currentThread());
	}

	@Override
	public ServletConfig getServletConfig() {		
		return null;
	}

	@Override
	public void service(ServletRequest req, ServletResponse res) throws ServletException, IOException {
		System.out.println("service");
	
		// (1) obtain an input info
		String name = req.getParameter("name");

		String login = req.getParameter("login");
		System.out.println(login.length());
		
		// (2) generate a result 
		String result = "Hi, " + name + "!";
		
		// (3)
		req.setAttribute("result", result);
		
		// (4) 
		req.getRequestDispatcher("result.jsp").forward(req, res);
		
		
		
		
		System.out.println("name ==> " + name);
		
		res.getWriter().printf("<html><body><h3>Hi, %s</body></html>", name);

	}

	@Override
	public String getServletInfo() {
		return null;
	}

	@Override
	public void destroy() {
		System.out.println("destroy");
	}

}
