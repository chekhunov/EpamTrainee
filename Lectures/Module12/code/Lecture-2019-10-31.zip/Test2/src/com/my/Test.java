package com.my;

import java.util.ArrayList;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		List list = new ArrayList() {
			{
				add(1);
				add(2);
			}
		};
		System.out.println(list);
	}

}
