package com.my;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// http://localhost:8080/Test/table?n=5
@WebServlet("/table")
public class TableServlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("TableServlet#doGet");
		
		// (1) obtain an input info
		int n = Integer.parseInt(request.getParameter("n"));
		System.out.println("n ==> " + n);
		
		// (2) generate a result
		Map<Integer, Integer> table = new HashMap<>();
		for (int j = 1; j <= n; j++) {
			table.put(j, j * j);
		}
		
		// (3) save a result in container
		request.setAttribute("table", table);
		
		// (4) go to jsp
		request.getRequestDispatcher("table.jsp")
			.forward(request, response);
	}

}
