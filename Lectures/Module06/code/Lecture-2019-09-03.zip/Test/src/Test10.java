public class Test10 {
	
	static class A implements AutoCloseable {
		public void close() throws Exception {
			System.out.println("A#close");
			throw new Exception("from close");
		}
	}
	
	public static void main(String[] args) {
		try (A a = new A()) {
			System.out.println("try");
			throw new NullPointerException();
		} catch (Exception ex) {
			System.out.println("catch");
			
			//ex.printStackTrace();
			System.out.println(ex.getSuppressed().length);
			Throwable s = ex.getSuppressed()[0];
			s.printStackTrace();
		} 
		
	}
}