import java.lang.Thread.UncaughtExceptionHandler;

public class Test {
	
	static void m() {
		int x = 7 / 0; // ArithmeticException  ex
		System.out.println("ok");
	}
	
	public static void main(String[] args) {
		Thread.setDefaultUncaughtExceptionHandler(
				new UncaughtExceptionHandler() {
					public void uncaughtException(Thread t, Throwable e) {
						e.printStackTrace();
					}
				}
			);
		
		
		
		m();
	}


}


