import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Test6 {
	
	
	public static void main(String[] args) {
		try (Scanner s = 
				new Scanner(new File(".project2"))) {
		
			while (s.hasNextLine()) {
				System.out.println(s.nextLine());
			}

		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} 
	}

	public static void main2(String[] args) throws FileNotFoundException {
		Scanner s = new Scanner(new File(".project"));
		
		while (s.hasNextLine()) {
			System.out.println(s.nextLine());
		}
		
		s.close();

	}

}


