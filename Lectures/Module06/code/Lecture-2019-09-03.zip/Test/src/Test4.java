
public class Test4 {
	
	static int m() {
		int x = 7;
		
		try {
			throw new NullPointerException();
		} catch (Exception ex) {
			return x;
		} finally {
			x = 8;
			return x;
		}
	}

	public static void main(String[] args) {
		System.out.println(m());
	}
}


