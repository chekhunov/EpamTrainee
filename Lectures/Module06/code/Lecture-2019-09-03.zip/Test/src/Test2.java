
public class Test2 {
	
	static void m() {
//		int x = 7 / 0; // ArithmeticException  ex
		ArithmeticException ex = 
			new ArithmeticException("AAAAAAAA");
		
		throw ex;
	}
	
	public static void main(String[] args) {
		m();
	}


}


