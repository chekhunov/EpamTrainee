import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Test5 {
	
	public static void main(String[] args) {
		try {
			m();
		}  catch (NullPointerException ex) {
			System.out.println(ex.getSuppressed().length);
		}
	}
	
	static void m() {
		Scanner s = null;
		try {
			s = new Scanner(new File(".project2"));
		
			while (s.hasNextLine()) {
				System.out.println(s.nextLine());
			}
		} catch (FileNotFoundException ex) {
			s.close();
			ex.printStackTrace();
		} finally {

		}

	}

	public static void main2(String[] args) throws FileNotFoundException {
		Scanner s = new Scanner(new File(".project"));
		
		while (s.hasNextLine()) {
			System.out.println(s.nextLine());
		}
		
		s.close();

	}

}


