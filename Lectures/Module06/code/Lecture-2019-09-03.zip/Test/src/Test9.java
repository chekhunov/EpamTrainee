public class Test9 {
	
	static class A implements AutoCloseable {
		public void close() {
			System.out.println("A#close");
		}
	}
	
	public static void main(String[] args) {
		try (A a = new A()) {
			System.out.println("try");
			throw new NullPointerException();
		} catch (Exception ex) {
			System.out.println("catch");
		} 
		
	}
}