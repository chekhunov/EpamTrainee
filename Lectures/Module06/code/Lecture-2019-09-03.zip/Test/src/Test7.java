import java.io.IOException;

public class Test7 {
	public static void main(String[] args) {
		Parent p = new Child();
		p.m();
	}
	
}

class Parent {
	void m() {

	}
}

class Child extends Parent {
	void m() throws RuntimeException, Error {

	}
}




