
public class Test3 {
	
	static void m() throws Exception {
		Exception ex = 
			new ArithmeticException("AAAAAAAA");
		
		throw ex;
	}
	
	public static void main(String[] args) {
		try {
			m();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}


