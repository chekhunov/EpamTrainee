public class Test8 {
	public static void main(String[] args) {
		P p = new C();
		try {
			p.m();
		} catch (CourierException ex) {
			Throwable t = ex.getCause();
//			t.printStackTrace();
			ex.printStackTrace();
		}
		
	}
	
}

class P {
	void m() {

	}
}

class C extends P{
	void m() {
		try {
			throw new Exception("from Child");
		} catch (Exception ex) {
			throw new CourierException(ex);
		}
	}
}


class CourierException extends RuntimeException { 
	public CourierException(Throwable t) {
		super(t);
	}
}



