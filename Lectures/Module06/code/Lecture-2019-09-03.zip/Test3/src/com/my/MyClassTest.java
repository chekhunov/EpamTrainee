package com.my;

import org.junit.Test;

import org.junit.Assert;

public class MyClassTest {
	
	@Test
	public void testAdd() {
		int actual = MyClass.add(2, 3);
		int expected = 5;
		Assert.assertEquals(expected, actual);
	}

	@Test
	public void testAdd2() {
		int actual = MyClass.add(Integer.MAX_VALUE, 1);
		int expected = Integer.MIN_VALUE;
		Assert.assertEquals(expected, actual);
	}

	@Test
	public void testDiv() {
		int actual = MyClass.div(8, 4);
		int expected = 2;
		Assert.assertEquals(expected, actual);
	}

	@Test
	public void testDiv2() {
		int actual = MyClass.div(7, 2);
		int expected = 3;
		Assert.assertEquals(expected, actual);
	}

	@Test(expected = Exception.class)
	public void testDiv3() {
		MyClass.div(7, 0);
	}

}
