
public class Test {

	// java -ea
	public static void main(String[] args) {
		assert 2 == 3 : "2 is not equal to 3!!!";
		System.out.println("ok");
	}

}
