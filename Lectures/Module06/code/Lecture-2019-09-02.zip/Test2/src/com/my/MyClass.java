package com.my;

public class MyClass {
	
	static int add(int x, int y) {
		return x + y;
	}

	static int div(int x, int y) {
		return x / y;
	}

}
