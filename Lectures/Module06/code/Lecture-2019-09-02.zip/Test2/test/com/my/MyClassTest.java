package com.my;

import org.junit.Assert;
import org.junit.Test;

public class MyClassTest {

	@Test
	public void testAdd() {
		int actual = MyClass.add(2, 3);
		int expected = 5;
		Assert.assertEquals(expected, actual);
	}

	@Test
	public void testAdd2() {
		int actual = MyClass.add(Integer.MAX_VALUE, 1);
		Assert.assertEquals(Integer.MIN_VALUE, actual);
	}

	@Test
	public void testDiv() {
		int actual = MyClass.div(8, 2);
		Assert.assertEquals(4, actual);
	}

	@Test
	public void testDiv2() {
		int actual = MyClass.div(7, 2);
		Assert.assertEquals(3, actual);
	}

	@Test(expected = ArithmeticException.class)
	public void testDiv3() {
		int actual = MyClass.div(17, 0);
	}

}
