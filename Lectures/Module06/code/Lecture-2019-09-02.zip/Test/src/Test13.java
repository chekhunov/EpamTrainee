public class Test13 {

	static class A implements AutoCloseable {
		public void close() throws Exception {
			System.out.println("A#close");
			throw new Exception("from close");
		}
	}

	public static void main(String[] args) {
		try (A a = new A()) {
			throw new NullPointerException();
		} catch (Exception ex) {
			System.out.println(ex);
			System.out.println(ex.getSuppressed().length);
			
			System.out.println(ex.getSuppressed()[0]);
		}
	}
}

