import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Test10 {
	public static void main(String[] args) {
		try (Scanner s = 
				new Scanner(new File(".project"))) {

			while (s.hasNextLine()) {
				System.out.println(s.nextLine());
			}
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		}		
	}
}
