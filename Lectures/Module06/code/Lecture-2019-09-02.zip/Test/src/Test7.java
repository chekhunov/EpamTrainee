
public class Test7 {
	public static void main(String[] args) {
		try {
			System.out.println("try");
			int x = 7 / 0;
		} catch (Exception ex) {
			System.out.println("catch");
		} finally {
			System.out.println("finally");
		}
	}
}
