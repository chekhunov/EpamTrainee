
public class Test6 {

	static void m() {
		try {
			int x = 7 / 0;
		} finally {
			System.out.println("finally");
			Object o = null;
			o.toString();
		}
	}
	
	public static void main(String[] args) {
		try {
			m();
		} catch (Exception ex) {
			System.out.println(ex.getSuppressed().length);

		}
	}

}
