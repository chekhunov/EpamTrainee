
public class Test3 {
	
	static void m() throws Exception {
		Exception ex = new Exception();
		System.out.println(ex.hashCode());
		throw ex;
	}
	
	public static void main(String[] args) {
		try {
			m();
		} catch (Exception e) {
//			e.printStackTrace();
			System.out.println(e.hashCode());
		}
	}

}
