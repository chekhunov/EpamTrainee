public class Test9 {
	
	static int m() {
		int x = 7;
		try {
			throw new Exception();
		} catch (Exception ex) {
			return x; // 7
		} finally {
			x = 8;
			return x;
		}
	}
	
	public static void main(String[] args) {
		System.out.println(m());
	}
}
