import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Test8 {
	public static void main(String[] args) {
		Scanner s = null;
		try {
			s = new Scanner(new File(".project"));
			while (s.hasNextLine()) {
				System.out.println(s.nextLine());
			}
		} catch (FileNotFoundException ex) {
			ex.printStackTrace();
		} finally {
			if (s != null) {
				s.close();
			}
		}
		
		

		
	}
}
