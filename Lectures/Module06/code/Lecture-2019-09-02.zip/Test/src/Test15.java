public class Test15 {

	// -ea
	public static void main(String[] args) {
		assert args.length != 2 : "Must be two args!!!";
		
		assert 2 == 3 : "2 does not equal to 3!!!!";
		System.out.println("ok");
	}
}