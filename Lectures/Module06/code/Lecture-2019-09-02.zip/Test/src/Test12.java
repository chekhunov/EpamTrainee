public class Test12 {
}

class Parent {
	void m() {
		
	}
}

class Child extends Parent {
	void m() throws RuntimeException, Error {

	}
}