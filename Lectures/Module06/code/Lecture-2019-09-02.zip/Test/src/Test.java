import java.lang.Thread.UncaughtExceptionHandler;

public class Test {
	
	public static void main(String[] args) {
		
		Thread.setDefaultUncaughtExceptionHandler(
				new UncaughtExceptionHandler() {
					
					public void uncaughtException(Thread t, Throwable e) {
						e.printStackTrace();
					}
				}
				);
		
		int x = 7 / 0;
		System.out.println("ok");

	}

}
