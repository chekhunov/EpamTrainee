public class Test14 {

	public static void main(String[] args) {
		P p = new C();
		try {
			p.m();
		} catch (ContainerException ex) {
			Throwable cause = ex.getCause();
			cause.printStackTrace();
//			ex.printStackTrace();
		}
	}
}


class P {
	void m() {}
}

class C extends P {
	void m() {
		try {
			throw new Exception("from child!!!");
		} catch (Exception ex) {
			throw new ContainerException(ex);
		}
	}
}

class ContainerException extends RuntimeException {
	public ContainerException(Throwable cause) {
		super(cause);
	}
}