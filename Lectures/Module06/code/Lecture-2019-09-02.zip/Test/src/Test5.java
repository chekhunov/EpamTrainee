
public class Test5 {

	public static void main(String[] args) {
		try {
			int x = 7 / 0;
		} finally {
			System.out.println("finally");
			Object o = null;
			o.toString();
		}
		
	}

}
