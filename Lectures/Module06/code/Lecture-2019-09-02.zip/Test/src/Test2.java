
public class Test2 {
	
	static void m() {
		int x = 7 / 0;
	}
// main --> m	
	public static void main(String[] args) {
		m();

	}

}
