public class Test11 {
	public static void main(String[] args) {
		try (A a = new A()) {
			System.out.println("try");
			int x = 7 / 0;
		} catch (Exception ex) {
			System.out.println("catch");
		} finally {
			System.out.println("finally");
		}
	}
}

class A implements AutoCloseable {
	public void close() {
		System.out.println("A#close");
	}
}
