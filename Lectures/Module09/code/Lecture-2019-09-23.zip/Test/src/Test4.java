
public class Test4 {
	
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder("asdf");
		StringBuilder sb2 = new StringBuilder("asdf");
		
		System.out.println(sb.equals(sb2));
	}

}
