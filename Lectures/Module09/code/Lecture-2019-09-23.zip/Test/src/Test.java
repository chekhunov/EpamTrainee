
public class Test {
	
	public static void main(String[] args) {
		String s = null;
		StringBuilder sb = null;
		
		Object o = sb;
		
//		System.out.println(s == sb);
		System.out.println(s == o);
	}

}
