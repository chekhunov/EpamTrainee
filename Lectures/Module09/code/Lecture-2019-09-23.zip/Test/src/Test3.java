
public class Test3 {
	
	public static void main(String[] args) {
		//Double d = 0 / 0;
		
		Double d = 0. / 0;
		Double d2 = 0. / 0;
		
		System.out.println(d.equals(d2));
		
		double t = 0. / 0;
		double t2 = 0. / 0;
		
		System.out.println(t == t2);
		
		System.out.println(d == t2);

	}

}
