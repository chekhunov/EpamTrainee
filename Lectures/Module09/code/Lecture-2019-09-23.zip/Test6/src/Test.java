import java.util.Arrays;

public class Test {
	
	public static void main(String[] args) {
		H h;
		
		h = new H() {
			public void m(int x) {
				System.out.printf("Anonymous#m(%s)%n", x);
			}
		};
		
		h.m(7);

		h = (int x) -> {
			System.out.printf("Lambda#m(%s)%n", x);
		};

		h = (x) -> {
			System.out.printf("Lambda#m(%s)%n", x);
		};

		h = (x) -> System.out.printf("Lambda#m(%s)%n", x);
		
		h.m(8);
		
		G g;
		g =  new G() {
			public char m(String s, int x) {
				return 'z';
			}
			
		};
		
		g = String::charAt;
		System.out.println(g.m("asdf", 2));
		
		g = C::n;
		System.out.println(g.m("asdf", 2));
		
		
		J j = String::new;
		
		R r = int[]::new;
		
		System.out.println(Arrays.toString(r.asdfdsa(5)));
	}

}

interface H {
	void m(int x);
}

interface G {
	char m(String s, int x);
}

class C {
	static char n(String s, int x) {
		return s.charAt(x);
	}
}

interface J {
	String asdfasdfasdfasdf(byte[] bytes);
}

interface R {
	int[] asdfdsa(int x);
}