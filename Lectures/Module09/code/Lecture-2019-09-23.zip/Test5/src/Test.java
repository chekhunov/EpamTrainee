import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashSet;
import java.util.TreeSet;

public class Test {
	
	public static void main(String[] args) {
		Collection<A> col;
		col = new ArrayList<>();
		col = new HashSet<>();
		col = new TreeSet<>();

		col = new TreeSet<>(new Comparator<A>() {
			public int compare(A a, A a2) {
				System.out.printf("Comp#compare(%s,%s)%n", a.x, a2.x);
				return -a.x + a2.x;
			}
		});

		col = new TreeSet<>((A a, A a2) -> -a.x + a2.x);
		col = new TreeSet<>((a, a2) -> -a.x + a2.x);
		
		col.add(new A(1));
		System.out.println("~~~");
		col.add(new A(2));
		System.out.println("~~~");
		col.add(new A(3));
		System.out.println("~~~");
		col.add(new A(4));
		System.out.println("~~~");
		
		System.out.println(col);
		
		System.out.println("~~~");
		
		System.out.println(
			col.contains(new A(5)));
	}

}

class A implements Comparable<A> {
	int x;
	A(int x) { this.x = x; }
	public String toString() { return "A(" + x + ")"; }
	
	public boolean equals(Object obj) {
		A a = (A)obj;
		System.out.printf("A(%s).equals(%s)%n", x, a.x);
		return x == a.x;
	}
	
	public int hashCode() {
		System.out.printf("A(%s).hashCode()%n", x);
		return x;
	}

	public int compareTo(A a) {
		System.out.printf("A(%s).compareTo(%s)%n", x, a.x);
		return x - a.x;
	}
	
	
	
}
