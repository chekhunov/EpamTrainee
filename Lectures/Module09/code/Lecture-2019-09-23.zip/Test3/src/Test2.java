public class Test2 {
	
	public static void main(String[] args) {
		System.out.println("asdf".compareTo("csdf"));
		System.out.println("asdf".compareTo("asdfasdf"));

		System.out.println("����p".compareTo("����"));
		
		// Collator
	}

}
