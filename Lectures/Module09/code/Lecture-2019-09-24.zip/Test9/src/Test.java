import java.util.Arrays;

public class Test {
	
	public static void main(String[] args) {
		J j;
		j = new J() {
			public void m(int x) {
				System.out.printf("Anonymous#m(%s)%n", x);
			}
		};
		j.m(7);
		
		j  = (int x) -> {
			System.out.printf("Lambda#m(%s)%n", x);
		};

		j  = x -> System.out.printf("Lambda#m(%s)%n", x);
		j.m(8);

		j  = C::n; // reference to static method
		j.m(9);
		
		// char m(String s, int x);
		H h = String::charAt;
		System.out.println(h.m("asdf", 2));
		
		// String m(char[] chars);
		R r = String::new;
		System.out.println(r.m(new char[] {'a', 'b', 'c'}));

		// int[] m(int x);

		T t = int[]::new;
		System.out.println(Arrays.toString(t.m(5)));
	}

}

@FunctionalInterface
interface J {
	void m(int x);
}


class C {
	static void n(int x) {
		System.out.printf("C.n(%s)%n", x);
	}
}

interface H {
	char m(String s, int x);
}

interface R {
	String m(char[] chars);
}

interface T {
	int[] m(int x);
}