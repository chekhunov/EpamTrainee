
public class Test3 {
	
	public static void main(String[] args) {
		StringBuilder sb = new StringBuilder();
		StringBuilder sb2 = new StringBuilder();
		System.out.println(sb.equals(sb2));
	}
}
