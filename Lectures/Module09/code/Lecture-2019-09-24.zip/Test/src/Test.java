
public class Test {
	
	public static void main(String[] args) {
//		System.out.println(3 == true);
//		System.out.println(false == true);
		
		String s = null;
		StringBuilder sb = null;
		
		Object o = sb;
		
//		System.out.println(s == sb);
		System.out.println(s == o);
		
		
		Integer x = 7; // int ==> Integer
		System.out.println(x == 7);
	}

}
