
public class Test2 {
	
	public static void main(String[] args) {
		
		Integer x = 127; // 
		Integer x2 = 127;
		
		System.out.println(x == x2);

		x = 128;
		x2 = 128;
		
		System.out.println(x == x2);

		System.out.println(x.equals(x2));

	}

}
