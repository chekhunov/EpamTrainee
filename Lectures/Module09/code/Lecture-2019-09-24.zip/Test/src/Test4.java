
public class Test4 {
	
	public static void main(String[] args) {
		System.out.println("asdfasdfasdfasdfasdf".hashCode());
		System.out.println("asdfasefasdfasdfasdf".hashCode());
	}
}
