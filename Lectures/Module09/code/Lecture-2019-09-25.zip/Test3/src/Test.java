import java.util.HashMap;
import java.util.Map;

public class Test {
	
	public static void main(String[] args) {
		Map<A, String> map = new HashMap<>();

		map.put(new A(1), "A");
		map.put(new A(2), "B");
		map.put(new A(3), "C");
		
		System.out.println(map);
	}
}

class A {
	int x;
	A(int x) { this.x = x; }
	public String toString() { return "A(" + x + ")"; }
	
	public boolean equals(Object obj) {
		A a = (A)obj;
//		return x == a.x;
		return true;
	}
	
	public int hashCode() {
//		return x;
		return 0;
	}
}
