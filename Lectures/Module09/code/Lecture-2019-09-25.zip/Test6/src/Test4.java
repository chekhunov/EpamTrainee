import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Test4 {
	
	public static void main(String[] args) {
		List<Number> list = Arrays.<Number>asList(1.1, 2, 3);
		List<Comparable> list2 = Arrays.<Comparable>asList(1.1, 2, 3);
		
		Object o = new C().m();
		System.out.println(o);
		
		
		String s = null; // Null-type ==> String
	}
}



class C {
	<T extends Number> T m() {
		return null;
	}
}



