import java.util.Properties;

public class Test {
	
	public static void main(String[] args) {
		// Hashtable vs HashMap
		
		Properties props = System.getProperties();
		props.list(System.out);
	}
}
