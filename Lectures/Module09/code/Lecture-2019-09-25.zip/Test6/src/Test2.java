import java.util.Arrays;
import java.util.Properties;

public class Test2 {
	
	public static void main(String[] args) {
		// Hashtable vs HashMap
		
		Properties props = new Properties();
		
		props.put("key", "value");
		
		System.out.println(props.getProperty("key"));
		
		System.out.println(System.getProperty("user.dir"));
		
		String eol = System.getProperty("line.separator");
		
		System.out.println(Arrays.toString(eol.getBytes()));
	}
}
