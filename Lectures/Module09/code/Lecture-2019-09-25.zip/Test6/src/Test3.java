import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class Test3 {
	
	public static void main(String[] args) {
		
		List<String> list = new ArrayList<>();
		list.add("A");
		list.add("C");
		list.add("B");

		Collections.sort(list);
		System.out.println(list);

		Collections.sort(list, Comparator.reverseOrder());
		System.out.println(list);
	}
}
