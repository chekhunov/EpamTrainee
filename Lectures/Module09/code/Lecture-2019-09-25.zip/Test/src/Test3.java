import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test3 {

	public static void main(String[] args) {
		List<String> col = new ArrayList<>();
		col.add("A");
		col.add("C");
		col.add("B");

		System.out.println(col);
		
		col.sort((s, s2) -> s.compareTo(s2));
		System.out.println(col);

		col.sort((s, s2) -> -s.compareTo(s2));
		System.out.println(col);
		
		col.stream().sorted().forEach(System.out::print);
		System.out.println();
		System.out.println(col);
		
		
		
	}
}