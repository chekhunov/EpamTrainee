import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.function.Consumer;

public class Test {
	
	public static void main(String[] args) {
		Collection<String> col = new ArrayList<>(); 
		col.add("A");
		col.add("B");
		col.add("C");
		
		// 0
		System.out.println(col);
		
		// 1
		for (String el : col) {
			System.out.print(el);
		}
		System.out.println();
		
		// 2
		Iterator<String> it = col.iterator();
		while (it.hasNext()) {
			System.out.print(it.next());
		}
		System.out.println();
		
//		for (int j = 0; j < col.size(); j++) {
// 			System.out.print(col.get(j)); // error for collections!!!
//		}
//		System.out.println();
		
		// 3
		col.forEach(new Consumer<String>() {
			public void accept(String el) {
				System.out.print(el);
			}
		});
		System.out.println();

		col.forEach((String el)  -> {
				System.out.print(el);
			}
		);
		System.out.println();

		col.forEach(el -> System.out.print(el));
		System.out.println();

		col.forEach(System.out::print);
		System.out.println();
		
		
		// 4
		col.stream().forEach(System.out::print);
		System.out.println();
		
		System.out.println("~~~");
		
		// 5
		for (Object el : col.toArray()) {
			System.out.print(el);
		}
		System.out.println();
		
		String[] ar = new String[5];
		System.out.println(Arrays.toString(col.toArray(ar)));

		ar = new String[2];
		System.out.println(Arrays.toString(col.toArray(ar)));
	}

}
