import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test4 {

	public static void main(String[] args) {
		List<B> list = new ArrayList<>();
		list.add(new B(1));
		list.add(new B(2));
		list.add(new B(3));
		
		list.stream().forEach(b -> b.x = 7);
		
		System.out.println(list);
	}
}

class B {
	int x;
	B(int x) { this.x = x; }
	public String toString() { return "A(" + x + ")"; }
}