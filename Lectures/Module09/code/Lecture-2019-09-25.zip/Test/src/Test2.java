import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Test2 {

	public static void main(String[] args) {
		List<String> col = new ArrayList<>();
		col.add("A");
		col.add("C");
		col.add("B");

		System.out.println(col);
		
		for (String el : col) { // iterator
			System.out.print(el);
		//	col.remove(el);
		}
		System.out.println();

		Iterator<String> it = col.iterator();
		//col.remove(1);
		//System.out.println(it.next());

		System.out.println(col);
		while (it.hasNext()) {
			System.out.println(it.next());
			it.remove();
		}
		System.out.println(col);
		
		
		
	}
}

class A implements Iterable<Integer> {

	@Override
	public Iterator<Integer> iterator() {
		return null;
	}
	
	
}