import java.util.HashMap;
import java.util.Map;

public class Test {
	
	public static void main(String[] args) {
		Map<A, String> map = new HashMap<>();

		map.put(new A(1), "A");
		map.put(new A(2), "B");
		
		A a = new A(3);
		map.put(a, "C");
		
		System.out.println(map);
		
		a.x = 1;

		System.out.println(map);
		System.out.println(map.get(a));
		
		map.forEach((k, v) -> 
			System.out.printf("%s=%s ", k, v));
		System.out.println();
		
		System.out.println(map.keySet());
	}
}

class A {
	int x;
	A(int x) { this.x = x; }
	public String toString() { return "A(" + x + ")"; }
	
	public boolean equals(Object obj) {
		A a = (A)obj;
		return x == a.x;
	}
	
	public int hashCode() {
		return x;
	}
}
