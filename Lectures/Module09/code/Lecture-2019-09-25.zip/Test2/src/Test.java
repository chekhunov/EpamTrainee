import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

public class Test {
	
	public static void main(String[] args) {
		Map<Integer, String> map = new HashMap<>();
		
		map.put(1, "A");
		map.put(2, "B");
		map.put(3, "C");
		
		// (0)
		System.out.println(map);
		
		// (1)
//		Set<Map.Entry<Integer, String>> entries = map.entrySet();
		for (Map.Entry<Integer, String> entry : map.entrySet()) {
			Integer key = entry.getKey();
			String value = entry.getValue();
			System.out.printf("%s=%s ", key, value);
		}
		System.out.println();
		
		// (2) bad!
		for (Integer key : map.keySet()) {
			String value = map.get(key); // 
			System.out.printf("%s=%s ", key, value);
		}
		System.out.println();
		
		// (3)
		map.forEach(new BiConsumer<Integer, String>() {
			public void accept(Integer key, String value) {
				System.out.printf("%s=%s ", key, value);
			}
		});
		System.out.println();

		map.forEach((key, value)  -> 
			System.out.printf("%s=%s ", key, value));

		System.out.println();
	}

}
