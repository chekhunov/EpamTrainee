import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Test2 {
	
	public static void main(String[] args) {
		Set<A> set = new HashSet<>();

		set.add(new A(1));
		set.add(new A(2));
		
		A a = new A(3);
		a.y = 100;
		set.add(a);
		
		System.out.println(set);
		
		A a2 = new A(3);
		System.out.println(a.equals(a2));
		
		System.out.println(set.contains(a2));
		
		A temp;
		Map<A, A> map = new HashMap<>();
		temp = new A(1);
		map.put(temp, temp);

		temp = new A(2);
		map.put(temp, temp);

		temp = new A(3);
		temp.y = 100;
		map.put(temp, temp);
		
		System.out.println(map.containsKey(a2));
		System.out.println(temp == map.get(a2));

		// a2.equals(temp) == true
		System.out.println(temp == a2); 
	}
}

class A {
	int x;
	int y;
	A(int x) { this.x = x; }
	public String toString() { return "A(" + x + ")"; }
	
	public boolean equals(Object obj) {
		A a = (A)obj;
		return x == a.x;
	}
	
	public int hashCode() {
		return x;
	}
}
