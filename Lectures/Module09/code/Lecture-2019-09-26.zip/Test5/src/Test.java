import java.util.Arrays;
import java.util.Properties;

public class Test {

	public static void main(String[] args) {
//		Properties props = new Properties();
		
		Properties props = System.getProperties();
		props.list(System.out);
		
		System.out.println("~~~");
		
		String eol = System.getProperty("line.separator");
		System.out.println(Arrays.toString(eol.getBytes()));
		

	}
}