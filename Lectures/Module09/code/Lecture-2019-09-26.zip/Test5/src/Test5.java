import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class Test5 {

	public static void main(String[] args) throws FileNotFoundException, IOException {
		Properties props = new Properties();

		
		props.load(new FileInputStream("app.properties"));
		
		System.out.println(props.getProperty("key"));
		System.out.println(props.getProperty("����"));
	}
}



