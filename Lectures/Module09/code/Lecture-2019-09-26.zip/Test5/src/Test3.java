import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Test3 {

	public static void main(String[] args) {
		List<Integer> list = new ArrayList<>();
		list.add(1);
		list.add(3);
		list.add(2);
		
		list.sort((x, x2) -> x - x2);
		System.out.println(list);

		list.sort((x, x2) -> -x + x2);
		System.out.println(list);
		
		Collections.sort(list);
		System.out.println(list);

		Collections.sort(list, (x, x2) -> -x + x2);
		System.out.println(list);

	}
}



