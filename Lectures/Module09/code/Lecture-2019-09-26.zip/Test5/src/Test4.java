import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Test4 {

	public static void main(String[] args) {
		List<? extends Object> list;
		
		list = new ArrayList<String>();
		list = new ArrayList<Integer>();
		
//		list.add(1); // <-- see 'get put principle!'
		
	}
}



