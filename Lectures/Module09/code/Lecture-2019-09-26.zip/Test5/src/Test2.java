import java.util.Arrays;
import java.util.List;

public class Test2 {

	public static void main(String[] args) {
//		List<Integer> list = Arrays.asList(1, 2, 3);
//		List<? extends Number> list = Arrays.asList(1, 2.2, 3.3);

		List<Object> list = Arrays.asList(1, 2.2, 3.3);
		
//		list.add(2);
		System.out.println(list.getClass());
	}
}



