import java.util.HashMap;
import java.util.Map;

public class Test {

	public static void main(String[] args) {
		Map<K, String> map = new HashMap<>();
		
		map.put(new K(1), "A");
		map.put(new K(2), "B");
		
		K k = new K(3);
		map.put(k, "C");
		
		System.out.println(map);
		
		String value = map.remove(k);
		k.x = 1;
		
		if (!map.containsKey(k)) {
			// implement your logic 
		}
	}
}

class K {

	int x;

	K(int x) { this.x = x; }

	public String toString() { return "A(" + x + ")"; }
	
	public boolean equals(Object obj) {
		K a = (K)obj;
		return x == a.x;
//		return true;
	}
	
	public int hashCode() {
		return x;
//		return 0;
	}
}