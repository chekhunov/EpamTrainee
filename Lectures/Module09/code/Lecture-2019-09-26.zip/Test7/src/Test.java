public class Test {
	public static void main(String[] args) {
		G g = C::n; // we can use n() here.
		// method n() returns a value which will be lost!

		g.m();
		
	}

}


interface G {
	void m();
}

class C {
	static String temp() {
		System.out.println("C.temp");
		return "aaaa";
	}

	static Object n() {
		System.out.println("C.n");
		return temp();
	}
}