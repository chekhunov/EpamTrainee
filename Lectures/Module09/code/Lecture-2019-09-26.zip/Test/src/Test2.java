import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class Test2 {

	public static void main(String[] args) {
		Collection<String> col = new ArrayList<>();

		col.add("A");
		col.add("B");
		col.add("C");
		
		System.out.println(col);
		
		Iterator<String> it = col.iterator();
		System.out.println(it.next());
		col.add("D");
		System.out.println(it.next());
	}
}