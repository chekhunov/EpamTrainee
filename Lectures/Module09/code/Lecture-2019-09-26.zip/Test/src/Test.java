import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.function.Consumer;

public class Test {
	
	public static void main(String[] args) {
		Collection<String> col = new ArrayList<>();
//		List<String> col = new ArrayList<>();
		
		col.add("A");
		col.add("C");
		col.add("B");
		
		// (0)
		System.out.println(col);
		
		// (1)
		for (String el : col) {
			System.out.print(el);
		}
		System.out.println();
		
		// (2)
		Iterator<String> it = col.iterator();
		while (it.hasNext()) {
			String el = it.next();
			System.out.print(el);
		}
		System.out.println();

		/*
		// 
		for (int j = 0; j < col.size(); j++) {
			String el = col.get(j);
			System.out.print(el);
		}
		System.out.println();
		*/
		
		// (3)
		col.forEach(new Consumer<String>() {
			public void accept(String el) {
				System.out.print(el);
			}
		});
		System.out.println();
	
		// (3.1)
		col.forEach(el -> System.out.print(el));
		System.out.println();

		// (3.2)
		col.forEach(System.out::print);
		System.out.println();
		
		System.out.println("~~~");
		
		col.stream().forEach(System.out::print);
		System.out.println();

		col.stream()
			.sorted()
			.forEach(System.out::print);
		System.out.println();

		System.out.println(col);

		col.stream()
			.sorted((s, s2) -> -s.compareTo(s2))
			.forEach(System.out::print);
		System.out.println();

		System.out.println(col);

	}

}



/*

Collection		==>  Iterable (iterator: Iterator)
	List			0 1 2 3
		ArrayList
		Vector
			Stack
		LinkedList
	Set
		TreeSet		compareTo | compare
		HashSet		equals | hachCode
	Queue
		Deque
			LinkedList
			
Collection < - - AbstractCollection
	List < - - AbstractList
	Set  < - - AbstractSet


*/
