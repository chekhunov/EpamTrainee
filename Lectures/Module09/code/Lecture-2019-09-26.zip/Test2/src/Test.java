import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;

public class Test {

	public static void main(String[] args) {
		Map<String, Integer> map = new HashMap<>();
		
		map.put("A", 1);
		map.put("B", 2);
		map.put("C", 3);
		
		// (0)
		System.out.println(map);
		
		// (1)
	//	Set<Map.Entry<String, Integer>> entries = map.entrySet();
		for (Map.Entry<String, Integer> entry : map.entrySet()) {
			String key = entry.getKey();
			Integer value = entry.getValue();
			System.out.printf("%s=%s ", key, value);
		}
		System.out.println();
	
		// (2) BAD!!!!! IT IS EVIL!!!!
		for (String key : map.keySet()) {
			Integer value = map.get(key);
			System.out.printf("%s=%s ", key, value);
		}
		System.out.println();
	
		// (3)
		map.forEach(new BiConsumer<String, Integer>() {
			public void accept(String key, Integer value) {
				System.out.printf("%s=%s ", key, value);
			}
		});
		System.out.println();

		// (3.1)
		map.forEach((key, value) -> 
			System.out.printf("%s=%s ", key, value));
		System.out.println();
				
	}
}