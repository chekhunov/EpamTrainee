import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Test2 {
	
	
	public static void main(String[] args) {
		Map<A, A> map = new HashMap<>();
		A a;

		a = new A(1);
		map.put(a, a);

		a = new A(2);
		map.put(a, a);

		a = new A(3);
		a.y = 1;
		map.put(a, a);
		
		
		a = new A(3);
		a.y = 100;
		
		A existed = map.get(a);
		System.out.println(existed.y);

	}

	

	public static void main2(String[] args) {
		Set<A> set = new HashSet<>();
		
		set.add(new A(1));
		set.add(new A(2));

		A a = new A(3);
		a.y = 1;
		set.add(a);
		
		System.out.println(set);
		
		A a2 = new A(3);
		a2.y = 100;
		System.out.println(a == a2);
		System.out.println(a.equals(a2));
		
//		set.remove(a2);
//		System.out.println(set);
		
		for (A el : set) {
			if (a2.equals(el)) {
				System.out.println(el.y);
			}
		}

	}
}

class A {
	int y;
	int x;
	A(int x) { this.x = x; }
	public String toString() { return "A(" + x + ")"; }
	
	public boolean equals(Object obj) {
		A a = (A)obj;
		return x == a.x;
	}
	
	public int hashCode() {
		return x;
	}
}